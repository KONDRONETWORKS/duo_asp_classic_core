using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.ServiceProcess;
using DuoAuthCore.Services;
using DuoAuthCore.Providers;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace DuoAuthCore
{
    /// <summary>
    /// Service Windows pour DuoAuthCore
    /// Permet d'exécuter l'application comme un service Windows
    /// </summary>
    public class DuoAuthService : ServiceBase
    {
        private IHost _host;
        private readonly ILogger<DuoAuthService> _logger;

        public DuoAuthService()
        {
            ServiceName = "DuoAuthCore";
            CanStop = true;
            CanPauseAndContinue = false;
            AutoLog = true;
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                // Créer le builder de l'application
                var builder = WebApplication.CreateBuilder(args);

                // Configurer pour fonctionner comme service Windows
                builder.Host.UseWindowsService();

                // Configuration des services
                builder.Services.AddControllers();
                builder.Services.AddEndpointsApiExplorer();

                // Configuration Duo Client Provider
                builder.Services.AddSingleton<IDuoClientProvider, DuoAuthCore.DuoClientProvider>();

                // Configuration DataProtection
                var keysPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DuoAuthCore", "keys");
                Directory.CreateDirectory(keysPath);
                builder.Services.AddDataProtection()
                    .PersistKeysToFileSystem(new DirectoryInfo(keysPath))
                    .SetApplicationName("DuoAuthCore");

                // Services de session et cache
                builder.Services.AddDistributedMemoryCache();
                builder.Services.AddSession(options =>
                {
                    options.IdleTimeout = TimeSpan.FromMinutes(60);
                    options.Cookie.HttpOnly = true;
                    options.Cookie.IsEssential = true;
                    options.Cookie.SameSite = SameSiteMode.Lax;
                    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                    options.Cookie.Name = "DuoAuth.Session";
                });

                // Configuration CORS
                builder.Services.AddCors(options =>
                {
                    options.AddPolicy("AllowAll", policy =>
                    {
                        policy.AllowAnyOrigin()
                              .AllowAnyMethod()
                              .AllowAnyHeader();
                    });
                });

                // Services utilitaires
                builder.Services.AddHttpContextAccessor();
                builder.Services.AddSingleton<TempAuthStorage>();

                // Logging
                builder.Logging.AddConsole();
                builder.Logging.AddDebug();
                builder.Logging.AddEventLog();

                // Construire l'application
                var app = builder.Build();

                // Middleware pipeline
                if (app.Environment.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }

                // Test config Duo au démarrage
                try
                {
                    var duoProvider = app.Services.GetRequiredService<IDuoClientProvider>();
                    var client = duoProvider.GetDuoClient();
                    app.Logger.LogInformation("✅ Configuration Duo VALIDE");
                }
                catch (Exception ex)
                {
                    app.Logger.LogError("❌ Configuration Duo ERREUR: {Message}", ex.Message);
                }

                app.UseRouting();
                app.UseCors("AllowAll");
                app.UseSession();

                // Debug session middleware
                app.Use(async (context, next) =>
                {
                    try
                    {
                        if (context.Session != null && context.Session.IsAvailable)
                        {
                            app.Logger.LogDebug("Session ID: {SessionId}, Keys: {Keys}",
                                context.Session.Id, string.Join(", ", context.Session.Keys));
                        }
                        else
                        {
                            app.Logger.LogWarning("⚠️ La session n'est pas disponible pour cette requête.");
                        }
                    }
                    catch (InvalidOperationException ex)
                    {
                        app.Logger.LogWarning("⚠️ Erreur session: {Message}", ex.Message);
                    }
                    await next();
                });

                app.MapControllers();
                app.MapGet("/health", () => new { status = "healthy", timestamp = DateTime.UtcNow });

                // Configuration pour écouter sur tous les ports disponibles
                // Le service écoutera sur les ports configurés dans IIS
                app.Urls.Add("http://0.0.0.0:8080");
                app.Urls.Add("https://0.0.0.0:8080");
                app.Urls.Add("http://0.0.0.0:2012");
                app.Urls.Add("https://0.0.0.0:2012");

                // Démarrer l'application
                _host = app;
                app.RunAsync();

                // Log de démarrage
                System.Diagnostics.EventLog.WriteEntry(ServiceName, "DuoAuthCore Service demarre avec succes", System.Diagnostics.EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry(ServiceName, $"Erreur lors du demarrage du service: {ex.Message}", System.Diagnostics.EventLogEntryType.Error);
                throw;
            }
        }

        protected override void OnStop()
        {
            try
            {
                _host?.StopAsync().Wait();
                System.Diagnostics.EventLog.WriteEntry(ServiceName, "DuoAuthCore Service arrete", System.Diagnostics.EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry(ServiceName, $"Erreur lors de l'arret du service: {ex.Message}", System.Diagnostics.EventLogEntryType.Error);
            }
        }

        protected override void OnShutdown()
        {
            OnStop();
        }
    }
}
