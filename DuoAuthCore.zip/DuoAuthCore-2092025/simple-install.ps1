# simple-install.ps1
# Installation simple du service DuoAuthCore

Write-Host "=== Installation Simple DuoAuthCore ===" -ForegroundColor Green

# 1. Compiler
Write-Host "1. Compilation..." -ForegroundColor Yellow
dotnet publish DuoAuthCore.csproj -c Release -o C:\inetpub\wwwroot\DuoAuthCore --self-contained false
Write-Host "✓ Compilation OK" -ForegroundColor Green

# 2. Creer dossiers
New-Item -ItemType Directory -Path "C:\inetpub\wwwroot\DuoAuthCore\logs" -Force | Out-Null
Write-Host "✓ Dossiers crees" -ForegroundColor Green

# 3. Supprimer anciens services
Write-Host "2. Suppression anciens services..." -ForegroundColor Yellow
$services = @("DuoAuthCore", "DuoAuthCoreService", "DuoAuthCoreNew")
foreach ($service in $services) {
    if (Get-Service -Name $service -ErrorAction SilentlyContinue) {
        Stop-Service -Name $service -Force -ErrorAction SilentlyContinue
        sc.exe delete $service 2>$null
    }
}
Write-Host "✓ Anciens services supprimes" -ForegroundColor Green

# 4. Attendre
Start-Sleep -Seconds 5

# 5. Creer nouveau service
Write-Host "3. Creation du service..." -ForegroundColor Yellow
$exePath = "C:\inetpub\wwwroot\DuoAuthCore\DuoAuthCore.exe"
$serviceName = "DuoAuthCore$(Get-Date -Format 'HHmmss')"
$result = sc.exe create $serviceName binPath="`"$exePath`" --service" DisplayName="DuoAuthCore Service" start= auto

if ($LASTEXITCODE -eq 0) {
    Write-Host "✓ Service cree: $serviceName" -ForegroundColor Green
    
    # Demarrer le service
    Start-Service -Name $serviceName
    Start-Sleep -Seconds 3
    
    $status = (Get-Service -Name $serviceName).Status
    Write-Host "✓ Service demarre: $status" -ForegroundColor Green
} else {
    Write-Host "❌ Echec creation service: $result" -ForegroundColor Red
}

Write-Host "=== Installation terminee ===" -ForegroundColor Green
