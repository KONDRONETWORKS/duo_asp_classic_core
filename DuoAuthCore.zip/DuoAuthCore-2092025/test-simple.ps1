# test-simple.ps1
# Test simple pour DuoAuthCore

$ServerIP = "172.16.32.40"
$HttpPort = 5000

Write-Host "=== Test Simple DuoAuthCore ===" -ForegroundColor Green

# Test HTTP Health
Write-Host "`nTest Health Check HTTP..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://$ServerIP`:$HttpPort/health" -UseBasicParsing
    Write-Host "✅ Health Check OK (Status: $($response.StatusCode))" -ForegroundColor Green
} catch {
    Write-Host "❌ Health Check ERREUR: $($_.Exception.Message)" -ForegroundColor Red
}

# Test Duo Auth
Write-Host "`nTest Duo Auth HTTP..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://$ServerIP`:$HttpPort/api/duoauth/duo-auth?username=test" -UseBasicParsing
    Write-Host "✅ Duo Auth OK (Status: $($response.StatusCode))" -ForegroundColor Green
    Write-Host "   Redirection vers Duo Security fonctionnelle" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Duo Auth ERREUR: $($_.Exception.Message)" -ForegroundColor Red
}

# Test avec différentes IPs
Write-Host "`nTest avec différentes IPs..." -ForegroundColor Yellow
$ips = @("172.16.32.40", "192.168.12.6", "192.168.22.6", "192.168.30.6")

foreach ($ip in $ips) {
    Write-Host "Test IP: $ip" -ForegroundColor White
    try {
        $response = Invoke-WebRequest -Uri "http://$ip`:$HttpPort/health" -UseBasicParsing -TimeoutSec 5
        Write-Host "  ✅ $ip OK" -ForegroundColor Green
    } catch {
        Write-Host "  ❌ $ip ERREUR" -ForegroundColor Red
    }
}

Write-Host "`n=== Test Terminé ===" -ForegroundColor Green
Write-Host "`nURLs d'accès depuis l'extérieur:" -ForegroundColor Cyan
Write-Host "  http://172.16.32.40:5000/health" -ForegroundColor White
Write-Host "  http://172.16.32.40:5000/api/duoauth/duo-auth?username=test" -ForegroundColor White
Write-Host "  http://192.168.12.6:5000/health" -ForegroundColor White
Write-Host "  http://192.168.12.6:5000/api/duoauth/duo-auth?username=test" -ForegroundColor White