# install-service-new.ps1
# Installation du service Windows DuoAuthCore avec un nouveau nom

param(
    [string]$ServiceName = "DuoAuthCoreService",
    [string]$PublishPath = "C:\inetpub\wwwroot\DuoAuthCore"
)

Write-Host "=== Installation Service DuoAuthCore (nouveau nom) ===" -ForegroundColor Green

# Vérifier les privilèges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit être exécuté en tant qu'administrateur."
    exit 1
}

# 1. Compilation et publication
Write-Host "`n1. Compilation..." -ForegroundColor Yellow
dotnet publish DuoAuthCore.csproj -c Release -o $PublishPath --self-contained false
if ($LASTEXITCODE -ne 0) {
    Write-Error "Échec de la compilation."
    exit 1
}
Write-Host "✅ Compilation OK" -ForegroundColor Green

# 2. Création des dossiers
Write-Host "`n2. Création des dossiers..." -ForegroundColor Yellow
if (-not (Test-Path $PublishPath)) {
    New-Item -Path $PublishPath -ItemType Directory -Force
}
if (-not (Test-Path "$PublishPath\logs")) {
    New-Item -Path "$PublishPath\logs" -ItemType Directory -Force
}
Write-Host "✅ Dossiers créés" -ForegroundColor Green

# 3. Suppression des anciens services
Write-Host "`n3. Suppression des anciens services..." -ForegroundColor Yellow
$oldServices = @("DuoAuthCore", "DuoAuthCoreService")
foreach ($oldService in $oldServices) {
    if (Get-Service -Name $oldService -ErrorAction SilentlyContinue) {
        Stop-Service -Name $oldService -ErrorAction SilentlyContinue
        sc.exe delete $oldService 2>$null
        Start-Sleep -Seconds 2
    }
}
Write-Host "✅ Anciens services supprimés" -ForegroundColor Green

# 4. Attendre un peu pour s'assurer que la suppression est finalisée
Start-Sleep -Seconds 5

# 5. Création du service
Write-Host "`n4. Création du service..." -ForegroundColor Yellow
$exePath = Join-Path $PublishPath "DuoAuthCore.exe"
$result = sc.exe create $ServiceName binPath="`"$exePath`" --service" DisplayName="DuoAuthCore Authentication Service" start= auto

if ($LASTEXITCODE -ne 0) {
    Write-Host "Erreur lors de la création: $result" -ForegroundColor Red
    Write-Host "Tentative avec un nom de service différent..." -ForegroundColor Yellow
    
    # Essayer avec un nom différent
    $ServiceName = "DuoAuthCore$(Get-Date -Format 'yyyyMMddHHmmss')"
    $result = sc.exe create $ServiceName binPath="`"$exePath`" --service" DisplayName="DuoAuthCore Authentication Service" start= auto
    
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Échec de la création du service avec tous les noms testés."
        Write-Host "Résultat: $result" -ForegroundColor Red
        exit 1
    }
}
Write-Host "✅ Service créé avec le nom: $ServiceName" -ForegroundColor Green

# 6. Configuration du pare-feu
Write-Host "`n5. Configuration du pare-feu..." -ForegroundColor Yellow
$ports = @(5000, 5001, 8080, 2012)
foreach ($port in $ports) {
    $ruleName = "$ServiceName Port $port"
    if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -DisplayName $ruleName
    }
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow
}
Write-Host "✅ Pare-feu configuré" -ForegroundColor Green

# 7. Démarrage du service
Write-Host "`n6. Démarrage du service..." -ForegroundColor Yellow
Start-Service -Name $ServiceName
Start-Sleep -Seconds 5
$serviceStatus = (Get-Service -Name $ServiceName).Status
if ($serviceStatus -eq "Running") {
    Write-Host "✅ Service démarré" -ForegroundColor Green
} else {
    Write-Warning "⚠️ Service non démarré (Statut: $serviceStatus)"
    Write-Host "L'application peut être lancée avec: dotnet run" -ForegroundColor Yellow
}

Write-Host "`n=== Installation terminée ===" -ForegroundColor Green
Write-Host "Service créé avec le nom: $ServiceName" -ForegroundColor Cyan
Write-Host "URLs d'accès:" -ForegroundColor Cyan
Write-Host "  http://172.16.32.40:5000/health" -ForegroundColor White
Write-Host "  http://172.16.32.40:5000/api/duoauth/duo-auth?username=test" -ForegroundColor White
