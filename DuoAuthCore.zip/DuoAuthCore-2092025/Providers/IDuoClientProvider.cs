using DuoUniversal;

namespace DuoAuthCore
{
    /// <summary>
    /// Interface pour fournir une instance configurée de DuoUniversal.Client
    /// </summary>
  
}
