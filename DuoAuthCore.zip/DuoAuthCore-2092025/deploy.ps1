# Script principal de deploiement DuoAuthCore
# Usage: .\deploy.ps1 [install|uninstall|test|status]

param(
    [string]$Action = "install"
)

Write-Host "=== DuoAuthCore Deployer ===" -ForegroundColor Green

# Verifier les privileges administrateur
if (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Error "Ce script doit etre execute en tant qu'administrateur"
    exit 1
}

if ($Action -eq "install") {
    Write-Host "`n=== INSTALLATION ===" -ForegroundColor Cyan
    
    # 1. Compiler
    Write-Host "1. Compilation..." -ForegroundColor Yellow
    dotnet publish -c Release -o C:\inetpub\wwwroot\DuoAuthCore --self-contained false
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Echec de la compilation"
        exit 1
    }
    Write-Host "✓ Compilation OK" -ForegroundColor Green
    
    # 2. Creer logs
    New-Item -ItemType Directory -Path "C:\inetpub\wwwroot\DuoAuthCore\logs" -Force | Out-Null
    Write-Host "✓ Dossier logs cree" -ForegroundColor Green
    
    # 3. Permissions
    icacls "C:\inetpub\wwwroot\DuoAuthCore" /grant "IIS_IUSRS:(OI)(CI)RX" /T | Out-Null
    Write-Host "✓ Permissions configurees" -ForegroundColor Green
    
    # 4. Installer service
    $serviceName = "DuoAuthCore"
    $servicePath = "C:\inetpub\wwwroot\DuoAuthCore\DuoAuthCore.exe"
    
    # Supprimer ancien service
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        Stop-Service -Name $serviceName -Force -ErrorAction SilentlyContinue
        sc.exe delete $serviceName
        Start-Sleep -Seconds 2
    }
    
    # Creer service
    sc.exe create $serviceName binPath= "$servicePath --service" start= auto DisplayName= "DuoAuthCore Service"
    sc.exe description $serviceName "Service d'authentification Duo pour Sigec4"
    sc.exe config $serviceName obj= "LocalSystem"
    
    # Demarrer service
    Start-Service -Name $serviceName
    Write-Host "✓ Service installe et demarre" -ForegroundColor Green
    
    # 5. Pare-feu
    $ports = @(8080, 2012)
    foreach ($port in $ports) {
        $ruleName = "DuoAuthCore Port $port"
        if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
            Remove-NetFirewallRule -DisplayName $ruleName
        }
        New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow
    }
    Write-Host "✓ Pare-feu configure" -ForegroundColor Green
    
    Write-Host "`n=== INSTALLATION TERMINEE ===" -ForegroundColor Green
    Write-Host "URLs disponibles:" -ForegroundColor Cyan
    Write-Host "  http://localhost:8080/health" -ForegroundColor White
    Write-Host "  http://localhost:2012/health" -ForegroundColor White
    Write-Host "  http://localhost:8080/api/duoauth/duo-auth?username=test" -ForegroundColor White
}
elseif ($Action -eq "uninstall") {
    Write-Host "`n=== DESINSTALLATION ===" -ForegroundColor Cyan
    
    $serviceName = "DuoAuthCore"
    
    # Arreter service
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        Stop-Service -Name $serviceName -Force
        sc.exe delete $serviceName
        Write-Host "✓ Service supprime" -ForegroundColor Green
    } else {
        Write-Host "⚠ Service non trouve" -ForegroundColor Yellow
    }
    
    # Supprimer regles pare-feu
    $ports = @(8080, 2012)
    foreach ($port in $ports) {
        $ruleName = "DuoAuthCore Port $port"
        if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
            Remove-NetFirewallRule -DisplayName $ruleName
        }
    }
    Write-Host "✓ Regles pare-feu supprimees" -ForegroundColor Green
    
    Write-Host "`n=== DESINSTALLATION TERMINEE ===" -ForegroundColor Green
}
elseif ($Action -eq "test") {
    Write-Host "`n=== TEST ===" -ForegroundColor Cyan
    
    # Test compilation
    Write-Host "1. Test compilation..." -ForegroundColor Yellow
    dotnet build -c Release
    if ($LASTEXITCODE -eq 0) {
        Write-Host "✓ Compilation OK" -ForegroundColor Green
    } else {
        Write-Host "❌ Echec compilation" -ForegroundColor Red
        exit 1
    }
    
    # Test service
    Write-Host "2. Test service..." -ForegroundColor Yellow
    $service = Get-Service -Name "DuoAuthCore" -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host "✓ Service: $($service.Status)" -ForegroundColor Green
    } else {
        Write-Host "❌ Service non installe" -ForegroundColor Red
    }
    
    # Test endpoints
    Write-Host "3. Test endpoints..." -ForegroundColor Yellow
    $endpoints = @("http://localhost:8080/health", "http://localhost:2012/health")
    foreach ($endpoint in $endpoints) {
        try {
            $response = Invoke-WebRequest -Uri $endpoint -UseBasicParsing -TimeoutSec 5
            if ($response.StatusCode -eq 200) {
                Write-Host "✓ $endpoint - OK" -ForegroundColor Green
            } else {
                Write-Host "⚠ $endpoint - Code: $($response.StatusCode)" -ForegroundColor Yellow
            }
        } catch {
            Write-Host "❌ $endpoint - Erreur" -ForegroundColor Red
        }
    }
    
    Write-Host "`n=== TEST TERMINE ===" -ForegroundColor Green
}
elseif ($Action -eq "status") {
    Write-Host "`n=== STATUT ===" -ForegroundColor Cyan
    
    # Statut service
    $service = Get-Service -Name "DuoAuthCore" -ErrorAction SilentlyContinue
    if ($service) {
        Write-Host "Service: $($service.Status)" -ForegroundColor Green
        Write-Host "Type: $($service.StartType)" -ForegroundColor Green
    } else {
        Write-Host "Service: Non installe" -ForegroundColor Red
    }
    
    # Ports
    Write-Host "`nPorts en ecoute:" -ForegroundColor Yellow
    $ports = @(8080, 2012)
    foreach ($port in $ports) {
        $connection = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
        if ($connection) {
            Write-Host "✓ Port $port - Actif" -ForegroundColor Green
        } else {
            Write-Host "❌ Port $port - Inactif" -ForegroundColor Red
        }
    }
    
    Write-Host "`n=== STATUT TERMINE ===" -ForegroundColor Green
}
else {
    Write-Host "Usage: .\deploy.ps1 [install|uninstall|test|status]" -ForegroundColor Yellow
    Write-Host "  install   - Installer le service" -ForegroundColor White
    Write-Host "  uninstall - Desinstaller le service" -ForegroundColor White
    Write-Host "  test      - Tester l'installation" -ForegroundColor White
    Write-Host "  status    - Afficher le statut" -ForegroundColor White
}