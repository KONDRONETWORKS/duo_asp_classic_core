# cleanup-ps1-files.ps1
# Script pour nettoyer la confusion des fichiers .ps1

Write-Host "=== Nettoyage des fichiers PowerShell ===" -ForegroundColor Red

# Fichiers à garder (essentiels)
$keepFiles = @(
    "deploy.ps1",
    "install-service.ps1", 
    "uninstall-service.ps1",
    "test-final.ps1"
)

# Fichiers à supprimer (redondants/confus)
$deleteFiles = @(
    "cleanup-service.ps1",
    "force-cleanup.ps1", 
    "install-service-admin.ps1",
    "install-service-new.ps1",
    "quick-cleanup.ps1",
    "simple-install.ps1",
    "test-external.ps1",
    "test-https.ps1",
    "test-service-status.ps1",
    "test-simple.ps1"
)

Write-Host "`nFichiers à conserver:" -ForegroundColor Green
foreach ($file in $keepFiles) {
    if (Test-Path $file) {
        Write-Host "  ✅ $file" -ForegroundColor Green
    } else {
        Write-Host "  ❌ $file (manquant)" -ForegroundColor Red
    }
}

Write-Host "`nFichiers à supprimer:" -ForegroundColor Yellow
foreach ($file in $deleteFiles) {
    if (Test-Path $file) {
        Write-Host "  🗑️  Suppression de $file" -ForegroundColor Yellow
        Remove-Item $file -Force
    } else {
        Write-Host "  ⚪ $file (déjà supprimé)" -ForegroundColor Gray
    }
}

Write-Host "`n=== Nettoyage terminé ===" -ForegroundColor Green
Write-Host "Fichiers PowerShell restants:" -ForegroundColor Cyan
Get-ChildItem -Name "*.ps1" | ForEach-Object { Write-Host "  📄 $_" -ForegroundColor Cyan }
