# cleanup-service.ps1
# Script pour nettoyer complètement le service DuoAuthCore

param(
    [string]$ServiceName = "DuoAuthCore"
)

Write-Host "=== Nettoyage Service DuoAuthCore ===" -ForegroundColor Red

# Vérifier les privilèges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit être exécuté en tant qu'administrateur."
    exit 1
}

Write-Host "✅ Privilèges administrateur OK" -ForegroundColor Green

# 1. Arrêter le service s'il est en cours d'exécution
Write-Host "`n1. Arrêt du service..." -ForegroundColor Yellow
try {
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    Write-Host "✅ Service arrêté" -ForegroundColor Green
} catch {
    Write-Host "ℹ️ Service déjà arrêté ou inexistant" -ForegroundColor Cyan
}

# 2. Supprimer le service
Write-Host "`n2. Suppression du service..." -ForegroundColor Yellow
try {
    sc.exe delete $ServiceName
    Write-Host "✅ Commande de suppression envoyée" -ForegroundColor Green
} catch {
    Write-Host "ℹ️ Service déjà supprimé" -ForegroundColor Cyan
}

# 3. Attendre la suppression complète
Write-Host "`n3. Attente de la suppression complète..." -ForegroundColor Yellow
for ($i = 1; $i -le 15; $i++) {
    $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if (-not $service) {
        Write-Host "✅ Service complètement supprimé après $i secondes" -ForegroundColor Green
        break
    }
    Write-Host "Attente... $i/15" -ForegroundColor Yellow
    Start-Sleep -Seconds 1
}

# 4. Vérifier l'état final
Write-Host "`n4. Vérification finale..." -ForegroundColor Yellow
$finalService = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($finalService) {
    Write-Host "⚠️ Service encore présent. Tentative de suppression forcée..." -ForegroundColor Yellow
    try {
        sc.exe stop $ServiceName
        sc.exe delete $ServiceName
        Start-Sleep -Seconds 5
    } catch {
        Write-Host "❌ Impossible de supprimer le service" -ForegroundColor Red
    }
} else {
    Write-Host "✅ Service complètement supprimé" -ForegroundColor Green
}

# 5. Nettoyer les processus dotnet
Write-Host "`n5. Nettoyage des processus dotnet..." -ForegroundColor Yellow
$dotnetProcesses = Get-Process -Name "dotnet" -ErrorAction SilentlyContinue
if ($dotnetProcesses) {
    Write-Host "Arrêt de $($dotnetProcesses.Count) processus dotnet..." -ForegroundColor Yellow
    Stop-Process -Name "dotnet" -Force -ErrorAction SilentlyContinue
    Write-Host "✅ Processus dotnet arrêtés" -ForegroundColor Green
} else {
    Write-Host "✅ Aucun processus dotnet en cours" -ForegroundColor Green
}

Write-Host "`n=== Nettoyage Terminé ===" -ForegroundColor Green
Write-Host "Vous pouvez maintenant relancer l'installation du service." -ForegroundColor Cyan
