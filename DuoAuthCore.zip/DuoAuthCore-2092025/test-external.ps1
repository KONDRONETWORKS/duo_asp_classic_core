# test-external.ps1
# Script pour tester l'accès externe à DuoAuthCore

param(
    [string]$ServerIP = "172.16.32.40",
    [int]$HttpPort = 5000,
    [int]$HttpsPort = 5001
)

Write-Host "=== Test Accès Externe DuoAuthCore ===" -ForegroundColor Green
Write-Host "Serveur: $ServerIP" -ForegroundColor Cyan
Write-Host "Port HTTP: $HttpPort" -ForegroundColor Cyan
Write-Host "Port HTTPS: $HttpsPort" -ForegroundColor Cyan

# Test HTTP
Write-Host "`n--- Test HTTP ---" -ForegroundColor Yellow
$httpEndpoints = @(
    "http://$ServerIP`:$HttpPort/health",
    "http://$ServerIP`:$HttpPort/api/duoauth/duo-auth?username=test"
)

foreach ($url in $httpEndpoints) {
    Write-Host "Test: $url" -ForegroundColor White
    try {
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✅ OK (Status: $($response.StatusCode))" -ForegroundColor Green
        } else {
            Write-Host "  ⚠️ ATTENTION (Status: $($response.StatusCode))" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "  ❌ ERREUR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Test HTTPS
Write-Host "`n--- Test HTTPS ---" -ForegroundColor Yellow
$httpsEndpoints = @(
    "https://$ServerIP`:$HttpsPort/health",
    "https://$ServerIP`:$HttpsPort/api/duoauth/duo-auth?username=test"
)

foreach ($url in $httpsEndpoints) {
    Write-Host "Test: $url" -ForegroundColor White
    try {
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✅ OK (Status: $($response.StatusCode))" -ForegroundColor Green
        } else {
            Write-Host "  ⚠️ ATTENTION (Status: $($response.StatusCode))" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "  ❌ ERREUR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Test des ports en écoute
Write-Host "`n--- Ports en écoute ---" -ForegroundColor Yellow
$ports = @($HttpPort, $HttpsPort)
foreach ($port in $ports) {
    $listening = netstat -an | Select-String ":$port" | Where-Object { $_ -match "LISTENING" }
    if ($listening) {
        Write-Host "  ✅ Port $port : $listening" -ForegroundColor Green
    } else {
        Write-Host "  ❌ Port $port : Non en écoute" -ForegroundColor Red
    }
}

Write-Host "`n=== Test Terminé ===" -ForegroundColor Green
