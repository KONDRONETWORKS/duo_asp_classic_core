# test-final.ps1
# Test final de DuoAuthCore

Write-Host "=== Test Final DuoAuthCore ===" -ForegroundColor Green

# Test des endpoints HTTP
$endpoints = @(
    "http://localhost:5000/health",
    "http://172.16.32.40:5000/health",
    "http://localhost:5000/api/duoauth/duo-auth?username=test",
    "http://172.16.32.40:5000/api/duoauth/duo-auth?username=test"
)

Write-Host "`nTest des endpoints HTTP..." -ForegroundColor Yellow
foreach ($url in $endpoints) {
    Write-Host "Test: $url" -ForegroundColor Cyan
    try {
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✅ OK (Status: $($response.StatusCode))" -ForegroundColor Green
        } else {
            Write-Host "  ⚠️ Status: $($response.StatusCode)" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "  ❌ ERREUR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Vérifier les ports en écoute
Write-Host "`nPorts en écoute:" -ForegroundColor Yellow
$ports = @(5000, 5001, 8080, 2012)
foreach ($port in $ports) {
    $listening = netstat -an | Select-String ":$port" | Where-Object { $_ -match "LISTENING" }
    if ($listening) {
        Write-Host "  ✅ Port $port : $listening" -ForegroundColor Green
    } else {
        Write-Host "  ❌ Port $port : Non en écoute" -ForegroundColor Red
    }
}

# Test avec différentes IPs
Write-Host "`nTest avec différentes IPs..." -ForegroundColor Yellow
$ipconfigOutput = ipconfig
$ipv4Addresses = ($ipconfigOutput | Select-String "Adresse IPv4" | ForEach-Object { $_.ToString().Split(':')[-1].Trim() })

foreach ($ip in $ipv4Addresses) {
    $externalHealthUrl = "http://$ip`:5000/health"
    Write-Host "Test IP: $ip" -ForegroundColor Cyan
    try {
        $response = Invoke-WebRequest -Uri $externalHealthUrl -UseBasicParsing -TimeoutSec 5
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✅ $ip OK" -ForegroundColor Green
        } else {
            Write-Host "  ❌ $ip ERREUR (Status: $($response.StatusCode))" -ForegroundColor Red
        }
    } catch {
        Write-Host "  ❌ $ip ERREUR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

Write-Host "`n=== Test Terminé ===" -ForegroundColor Green
Write-Host "`nURLs d'accès depuis l'extérieur:" -ForegroundColor Cyan
foreach ($ip in $ipv4Addresses) {
    Write-Host "  http://$ip`:5000/health" -ForegroundColor White
    Write-Host "  http://$ip`:5000/api/duoauth/duo-auth?username=test" -ForegroundColor White
}

Write-Host "`nPour installer le service Windows, exécutez en tant qu'administrateur:" -ForegroundColor Yellow
Write-Host "  .\install-service-final.ps1" -ForegroundColor White
