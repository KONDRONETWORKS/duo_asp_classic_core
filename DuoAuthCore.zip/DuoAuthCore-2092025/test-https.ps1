# test-https.ps1
# Test HTTPS pour DuoAuthCore

$ServerIP = "172.16.32.40"
$HttpsPort = 5001

Write-Host "=== Test HTTPS DuoAuthCore ===" -ForegroundColor Green
Write-Host "Serveur: $ServerIP" -ForegroundColor Cyan
Write-Host "Port HTTPS: $HttpsPort" -ForegroundColor Cyan

# Test HTTPS Health
Write-Host "`nTest Health Check HTTPS..." -ForegroundColor Yellow
try {
    # Ignorer les erreurs de certificat pour le test
    $response = Invoke-WebRequest -Uri "https://$ServerIP`:$HttpsPort/health" -UseBasicParsing -SkipCertificateCheck
    Write-Host "✅ Health Check HTTPS OK (Status: $($response.StatusCode))" -ForegroundColor Green
} catch {
    Write-Host "❌ Health Check HTTPS ERREUR: $($_.Exception.Message)" -ForegroundColor Red
}

# Test HTTPS Duo Auth
Write-Host "`nTest Duo Auth HTTPS..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "https://$ServerIP`:$HttpsPort/api/duoauth/duo-auth?username=test" -UseBasicParsing -SkipCertificateCheck
    Write-Host "✅ Duo Auth HTTPS OK (Status: $($response.StatusCode))" -ForegroundColor Green
    Write-Host "   Redirection vers Duo Security fonctionnelle" -ForegroundColor Cyan
} catch {
    Write-Host "❌ Duo Auth HTTPS ERREUR: $($_.Exception.Message)" -ForegroundColor Red
}

# Test localhost HTTPS
Write-Host "`nTest localhost HTTPS..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "https://localhost:$HttpsPort/health" -UseBasicParsing -SkipCertificateCheck
    Write-Host "✅ Localhost HTTPS OK (Status: $($response.StatusCode))" -ForegroundColor Green
} catch {
    Write-Host "❌ Localhost HTTPS ERREUR: $($_.Exception.Message)" -ForegroundColor Red
}

# Vérifier les ports en écoute
Write-Host "`nPorts en écoute:" -ForegroundColor Yellow
$ports = @(5000, 5001)
foreach ($port in $ports) {
    $listening = netstat -an | Select-String ":$port" | Where-Object { $_ -match "LISTENING" }
    if ($listening) {
        Write-Host "  ✅ Port $port : $listening" -ForegroundColor Green
    } else {
        Write-Host "  ❌ Port $port : Non en écoute" -ForegroundColor Red
    }
}

Write-Host "`n=== Test HTTPS Terminé ===" -ForegroundColor Green
Write-Host "`nURLs HTTPS d'accès depuis l'extérieur:" -ForegroundColor Cyan
Write-Host "  https://172.16.32.40:5001/health" -ForegroundColor White
Write-Host "  https://172.16.32.40:5001/api/duoauth/duo-auth?username=test" -ForegroundColor White
Write-Host "`nNote: Les certificats de développement peuvent générer des avertissements de sécurité." -ForegroundColor Yellow
