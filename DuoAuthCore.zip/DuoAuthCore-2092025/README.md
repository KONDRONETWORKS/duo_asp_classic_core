# 🚀 DuoAuthCore - Guide de Production

## 📋 Vue d'ensemble

**DuoAuthCore** est une application d'authentification Duo qui fonctionne en production sans nécessiter `dotnet run`.

## 🎯 Scripts Principaux

### 🚀 **Script de Gestion Unifié**
```powershell
.\manage.ps1 -Action [start|stop|status|test|restart|logs]
```

### 📋 **Scripts Spécialisés**
- **`start-background.ps1`** - Démarrage en arrière-plan
- **`stop-background.ps1`** - Arrêt de l'application
- **`test-url.ps1`** - Test des URLs spécifiques

## 🚀 **Démarrage Rapide**

### **1. Démarrer l'application**
```powershell
.\manage.ps1 -Action start
```

### **2. Vérifier le statut**
```powershell
.\manage.ps1 -Action status
```

### **3. Tester les endpoints**
```powershell
.\manage.ps1 -Action test
```

## 🌐 **URLs d'Accès**

- **Site principal :** `https://test.cafecacao.ci:2012
- **Health check :** `https://test.cafecacao.ci:2012/health`
- **API Duo Auth :** `https://test.cafecacao.ci:8080/api/duoauth/duo-auth?username=USERNAME&returnUrl=RETURN_URL`

### 📋 **Paramètres de l'API Duo Auth**

L'URL est construite par votre application ASP classique :
```asp
duoAuthUrl = "https://test.cafecacao.ci:8080/api/duoauth/duo-auth?username=" & Server.URLEncode(Identifiant) & _
            "&returnUrl=" & Server.URLEncode(returnUrl)
```

- **`username`** : Identifiant utilisateur (ex: gore, test, admin)
- **`returnUrl`** : URL de retour après authentification Duo

## 🔧 **Gestion Quotidienne**

### **Démarrer**
```powershell
.\manage.ps1 -Action start
```

### **Arrêter**
```powershell
.\manage.ps1 -Action stop
```

### **Redémarrer**
```powershell
.\manage.ps1 -Action restart
```

### **Voir le statut**
```powershell
.\manage.ps1 -Action status
```

### **Voir les logs**
```powershell
.\manage.ps1 -Action logs
```

### **Tester l'application**
```powershell
.\manage.ps1 -Action test
```

## 📁 **Fichiers Importants**

- **`manage.ps1`** - Script principal de gestion
- **`start-background.ps1`** - Démarrage en arrière-plan
- **`stop-background.ps1`** - Arrêt de l'application
- **`test-url.ps1`** - Test des URLs
- **`duoauthcore.pid`** - Fichier PID (créé automatiquement)

## ✅ **Avantages**

- ✅ **Plus besoin de `dotnet run`**
- ✅ **Application en arrière-plan**
- ✅ **Gestion simplifiée**
- ✅ **Scripts de test intégrés**
- ✅ **Logs automatiques**

## 🚨 **Dépannage**

### **Application ne démarre pas**
```powershell
.\manage.ps1 -Action status
.\manage.ps1 -Action logs
```

### **Port déjà utilisé**
```powershell
.\manage.ps1 -Action stop
.\manage.ps1 -Action start
```

### **Test de connectivité**
```powershell
.\manage.ps1 -Action test
```

## 🎉 **Résultat**

Votre application **DuoAuthCore** fonctionne maintenant comme un **service de production** sans nécessiter de terminal ouvert !

---

**📞 Support :** Utilisez `.\manage.ps1 -Action status` pour diagnostiquer les problèmes.