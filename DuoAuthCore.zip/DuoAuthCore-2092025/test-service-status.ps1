# test-service-status.ps1
# Test du statut du service et des ports

Write-Host "=== Test Statut Service DuoAuthCore ===" -ForegroundColor Green

# 1. Statut du service
Write-Host "`n1. Statut du service Windows..." -ForegroundColor Yellow
$service = Get-Service -Name "DuoAuthCoreService" -ErrorAction SilentlyContinue
if ($service) {
    Write-Host "Service: $($service.Name)" -ForegroundColor Cyan
    Write-Host "Statut: $($service.Status)" -ForegroundColor Cyan
    Write-Host "Type: $($service.ServiceType)" -ForegroundColor Cyan
} else {
    Write-Host "Service non trouvé" -ForegroundColor Red
}

# 2. Ports en écoute
Write-Host "`n2. Ports en écoute..." -ForegroundColor Yellow
$ports = @(5000, 5001, 8080, 2012)
foreach ($port in $ports) {
    $listening = netstat -an | Select-String ":$port" | Where-Object { $_ -match "LISTENING" }
    if ($listening) {
        Write-Host "  ✅ Port $port : $listening" -ForegroundColor Green
    } else {
        Write-Host "  ❌ Port $port : Non en écoute" -ForegroundColor Red
    }
}

# 3. Test des endpoints
Write-Host "`n3. Test des endpoints..." -ForegroundColor Yellow
$endpoints = @(
    "http://localhost:5000/health",
    "http://172.16.32.40:5000/health"
)

foreach ($url in $endpoints) {
    Write-Host "Test: $url" -ForegroundColor Cyan
    try {
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 5
        if ($response.StatusCode -eq 200) {
            Write-Host "  ✅ OK (Status: $($response.StatusCode))" -ForegroundColor Green
        } else {
            Write-Host "  ⚠️ Status: $($response.StatusCode)" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "  ❌ ERREUR: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# 4. Processus dotnet en cours
Write-Host "`n4. Processus dotnet en cours..." -ForegroundColor Yellow
$dotnetProcesses = Get-Process -Name "dotnet" -ErrorAction SilentlyContinue
if ($dotnetProcesses) {
    Write-Host "  ✅ $($dotnetProcesses.Count) processus dotnet trouvé(s)" -ForegroundColor Green
    foreach ($proc in $dotnetProcesses) {
        Write-Host "    PID: $($proc.Id), CPU: $($proc.CPU)" -ForegroundColor Cyan
    }
} else {
    Write-Host "  ❌ Aucun processus dotnet trouvé" -ForegroundColor Red
}

# 5. Règles de pare-feu
Write-Host "`n5. Règles de pare-feu..." -ForegroundColor Yellow
$firewallRules = Get-NetFirewallRule -DisplayName "*DuoAuthCoreService*" -ErrorAction SilentlyContinue
if ($firewallRules) {
    Write-Host "  ✅ $($firewallRules.Count) règles de pare-feu trouvées" -ForegroundColor Green
    foreach ($rule in $firewallRules) {
        Write-Host "    $($rule.DisplayName) - $($rule.Action)" -ForegroundColor Cyan
    }
} else {
    Write-Host "  ❌ Aucune règle de pare-feu trouvée" -ForegroundColor Red
}

Write-Host "`n=== Test Terminé ===" -ForegroundColor Green

# Recommandations
Write-Host "`nRecommandations:" -ForegroundColor Yellow
if ($service.Status -ne "Running") {
    Write-Host "  - Le service Windows ne fonctionne pas. Utilisez 'dotnet run' pour le développement." -ForegroundColor Yellow
}
if ($dotnetProcesses) {
    Write-Host "  - L'application fonctionne en mode développement avec 'dotnet run'." -ForegroundColor Green
    Write-Host "  - URLs d'accès: http://172.16.32.40:5000/health" -ForegroundColor Cyan
}
