# install-service-admin.ps1
# Script pour installer le service Windows (nécessite admin)

param(
    [string]$ServiceName = "DuoAuthCore",
    [string]$DisplayName = "DuoAuthCore Authentication Service",
    [string]$PublishPath = "C:\inetpub\wwwroot\DuoAuthCore"
)

Write-Host "=== Installation Service Windows DuoAuthCore ===" -ForegroundColor Green

# Vérifier les privilèges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit être exécuté en tant qu'administrateur."
    Write-Host "Clic droit sur PowerShell -> 'Exécuter en tant qu'administrateur'" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Privilèges administrateur OK" -ForegroundColor Green

# 1. Compiler et publier
Write-Host "`n1. Compilation et publication..." -ForegroundColor Yellow
dotnet publish DuoAuthCore.csproj -c Release -o $PublishPath --self-contained false
if ($LASTEXITCODE -ne 0) {
    Write-Error "Échec de la compilation et publication."
    exit 1
}
Write-Host "✅ Compilation OK" -ForegroundColor Green

# 2. Créer les dossiers
Write-Host "`n2. Création des dossiers..." -ForegroundColor Yellow
if (-not (Test-Path $PublishPath)) {
    New-Item -Path $PublishPath -ItemType Directory -Force
}
$LogPath = "$PublishPath\logs"
if (-not (Test-Path $LogPath)) {
    New-Item -Path $LogPath -ItemType Directory -Force
}
Write-Host "✅ Dossiers créés" -ForegroundColor Green

# 3. Supprimer le service existant
Write-Host "`n3. Suppression du service existant..." -ForegroundColor Yellow
if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    Stop-Service -Name $ServiceName -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName
    Write-Host "Attente de la suppression complète du service..." -ForegroundColor Yellow
    Start-Sleep -Seconds 10
    Write-Host "✅ Service existant supprimé" -ForegroundColor Green
} else {
    Write-Host "✅ Aucun service existant" -ForegroundColor Green
}

# 4. Créer le service
Write-Host "`n4. Création du service..." -ForegroundColor Yellow
$exePath = Join-Path $PublishPath "$ServiceName.exe"
if (-not (Test-Path $exePath)) {
    Write-Error "Fichier exécutable non trouvé: $exePath"
    exit 1
}

sc.exe create $ServiceName binPath="`"$exePath`" --service" DisplayName="$DisplayName" start= auto
if ($LASTEXITCODE -ne 0) {
    Write-Error "Échec de la création du service."
    exit 1
}
Write-Host "✅ Service créé" -ForegroundColor Green

# 5. Configurer le pare-feu
Write-Host "`n5. Configuration du pare-feu..." -ForegroundColor Yellow
$ports = @(5000, 5001, 8080, 2012)
foreach ($port in $ports) {
    $ruleName = "$ServiceName Port $port"
    if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -DisplayName $ruleName
    }
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow
    Write-Host "  ✅ Port $port configuré" -ForegroundColor Green
}

# 6. Démarrer le service
Write-Host "`n6. Démarrage du service..." -ForegroundColor Yellow
Start-Service -Name $ServiceName
Start-Sleep -Seconds 5

$serviceStatus = (Get-Service -Name $ServiceName).Status
if ($serviceStatus -eq "Running") {
    Write-Host "✅ Service démarré" -ForegroundColor Green
} else {
    Write-Warning "⚠️ Service non démarré. Statut: $serviceStatus"
}

# 7. Test des endpoints
Write-Host "`n7. Test des endpoints..." -ForegroundColor Yellow
$testUrls = @(
    "http://localhost:5000/health",
    "http://172.16.32.40:5000/health",
    "http://localhost:5000/api/duoauth/duo-auth?username=test"
)

foreach ($url in $testUrls) {
    try {
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 10
        Write-Host "  ✅ $url - OK" -ForegroundColor Green
    } catch {
        Write-Host "  ❌ $url - ERREUR" -ForegroundColor Red
    }
}

Write-Host "`n=== Installation Terminée ===" -ForegroundColor Green
Write-Host "`nURLs d'accès:" -ForegroundColor Cyan
Write-Host "  http://172.16.32.40:5000/health" -ForegroundColor White
Write-Host "  http://172.16.32.40:5000/api/duoauth/duo-auth?username=test" -ForegroundColor White
Write-Host "`nService Windows: $ServiceName" -ForegroundColor Cyan
Write-Host "Statut: $((Get-Service -Name $ServiceName).Status)" -ForegroundColor Cyan
