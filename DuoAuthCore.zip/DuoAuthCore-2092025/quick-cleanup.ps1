# quick-cleanup.ps1
# Nettoyage rapide des services DuoAuthCore

Write-Host "=== Nettoyage Rapide DuoAuthCore ===" -ForegroundColor Red

# 1. Arrêter et supprimer tous les services possibles
Write-Host "`n1. Suppression des services..." -ForegroundColor Yellow
$services = @("DuoAuthCoreService", "DuoAuthCore", "DuoAuthCore Authentication Service")

foreach ($serviceName in $services) {
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        Write-Host "Arrêt du service: $serviceName"
        Stop-Service -Name $serviceName -ErrorAction SilentlyContinue -Force
        Write-Host "Suppression du service: $serviceName"
        sc.exe delete $serviceName 2>$null
    }
}

# 2. Attendre que les services soient complètement supprimés
Write-Host "`n2. Attente de la suppression complète..." -ForegroundColor Yellow
Write-Host "Attente de 15 secondes pour que Windows termine la suppression..."
Start-Sleep -Seconds 15

# 3. Vérifier que les services sont vraiment supprimés
Write-Host "`n3. Vérification de la suppression..." -ForegroundColor Yellow
$allDeleted = $true
foreach ($serviceName in $services) {
    if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
        Write-Host "❌ Service $serviceName existe encore" -ForegroundColor Red
        $allDeleted = $false
    } else {
        Write-Host "✅ Service $serviceName supprimé" -ForegroundColor Green
    }
}

if ($allDeleted) {
    Write-Host "`n✅ Tous les services ont été supprimés avec succès!" -ForegroundColor Green
    Write-Host "Vous pouvez maintenant exécuter .\install-service.ps1" -ForegroundColor Cyan
} else {
    Write-Host "`n❌ Certains services existent encore. Redémarrez le serveur ou attendez plus longtemps." -ForegroundColor Red
}

Write-Host "`n=== Nettoyage terminé ===" -ForegroundColor Red