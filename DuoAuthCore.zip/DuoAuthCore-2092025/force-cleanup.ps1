# force-cleanup.ps1
# Script pour forcer la suppression complète du service DuoAuthCore

param(
    [string]$ServiceName = "DuoAuthCore"
)

Write-Host "=== Nettoyage force du service $ServiceName ===" -ForegroundColor Red

# Vérifier les privilèges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit etre execute en tant qu'administrateur."
    exit 1
}

# 1. Arreter le service de force
Write-Host "`n1. Arret force du service..." -ForegroundColor Yellow
try {
    Stop-Service -Name $ServiceName -Force -ErrorAction SilentlyContinue
    Write-Host "✓ Service arrete" -ForegroundColor Green
} catch {
    Write-Host "⚠ Service deja arrete ou inexistant" -ForegroundColor Yellow
}

# 2. Attendre un peu
Start-Sleep -Seconds 3

# 3. Supprimer le service
Write-Host "`n2. Suppression du service..." -ForegroundColor Yellow
$result = sc.exe delete $ServiceName 2>&1
Write-Host "Resultat: $result"

# 4. Verifier si le service existe encore
Start-Sleep -Seconds 2
$service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
if ($service) {
    Write-Host "⚠ Service encore present, tentative de suppression via le registre..." -ForegroundColor Yellow
    
    # 5. Suppression via le registre (methode avancee)
    try {
        $regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
        if (Test-Path $regPath) {
            Write-Host "Suppression de la cle de registre: $regPath" -ForegroundColor Yellow
            Remove-Item -Path $regPath -Recurse -Force
            Write-Host "✓ Cle de registre supprimee" -ForegroundColor Green
        }
        
        # Redemarrer le service de gestion des services
        Write-Host "Redemarrage du gestionnaire de services..." -ForegroundColor Yellow
        Restart-Service -Name "Service Control Manager" -Force -ErrorAction SilentlyContinue
        
        Start-Sleep -Seconds 5
        
        # Verifier a nouveau
        $service = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($service) {
            Write-Host "❌ Service toujours present - redemarrage requis" -ForegroundColor Red
            Write-Host "Veuillez redemarrer l'ordinateur pour finaliser la suppression." -ForegroundColor Yellow
        } else {
            Write-Host "✅ Service supprime avec succes" -ForegroundColor Green
        }
    } catch {
        Write-Host "❌ Erreur lors de la suppression via le registre: $($_.Exception.Message)" -ForegroundColor Red
    }
} else {
    Write-Host "✅ Service supprime avec succes" -ForegroundColor Green
}

# 6. Nettoyage des regles de pare-feu
Write-Host "`n3. Nettoyage des regles de pare-feu..." -ForegroundColor Yellow
$ports = @(5000, 5001, 8080, 2012)
foreach ($port in $ports) {
    $ruleName = "$ServiceName Port $port"
    if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -DisplayName $ruleName
        Write-Host "✓ Regle pare-feu supprimee: $ruleName" -ForegroundColor Green
    }
}

Write-Host "`n=== Nettoyage termine ===" -ForegroundColor Green
