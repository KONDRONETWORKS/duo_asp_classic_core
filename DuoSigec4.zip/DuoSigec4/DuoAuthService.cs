/*
 * ========================================================================
 * FICHIER : DuoAuthService.cs
 * ========================================================================
 * 
 * DESCRIPTION :
 * ------------
 * Ce fichier implémente un service Windows pour l'application DuoSigec4.
 * Il permet d'exécuter l'application d'authentification Duo comme un service
 * Windows en arrière-plan, sans interface utilisateur.
 * 
 * FONCTIONNALITÉS PRINCIPALES :
 * -----------------------------
 * 1. Héritage de ServiceBase pour le support des services Windows
 * 2. Configuration automatique de l'application ASP.NET Core
 * 3. Gestion du cycle de vie du service (démarrage/arrêt)
 * 4. Configuration des URLs d'écoute pour le service
 * 5. Logging intégré pour le monitoring
 * 
 * UTILISATION :
 * -------------
 * - Installation : sc create DuoAuth binPath="C:\path\to\DuoSigec4.exe --service"
 * - Démarrage : sc start DuoAuth
 * - Arrêt : sc stop DuoAuth
 * - Désinstallation : sc delete DuoAuth
 * 
 * CONFIGURATION :
 * ---------------
 * - ServiceName : "DuoSigec4"
 * - CanStop : true (peut être arrêté)
 * - CanPauseAndContinue : false (pas de pause/reprise)
 * - AutoLog : true (logging automatique vers EventLog)
 * 
 * SÉCURITÉ :
 * ----------
 * - Fonctionne avec les comptes de service Windows
 * - Accès restreint aux ressources système
 * - Logging des événements système
 * 
 * ========================================================================
 */

using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.ServiceProcess;
using DuoSigec4.Services;
using DuoSigec4.Providers;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;

namespace DuoSigec4
{
    /*
     * SERVICE WINDOWS DUO SIGEC4
     * ---------------------------
     * 
     * Ce service Windows permet d'exécuter l'application DuoSigec4
     * en arrière-plan comme un service système Windows.
     * 
     * AVANTAGES :
     * - Démarrage automatique avec Windows
     * - Fonctionnement en arrière-plan
     * - Gestion automatique des redémarrages
     * - Intégration avec l'EventLog Windows
     * - Monitoring via les outils Windows
     */
    public class DuoAuthService : ServiceBase
    {
        /*
         * CHAMPS PRIVÉS
         * --------------
         * 
         * - _host : Instance de l'hôte ASP.NET Core pour le service
         * - _logger : Logger pour les événements du service
         */
        private IHost _host;
        private readonly ILogger<DuoAuthService> _logger;

        /*
         * CONSTRUCTEUR DU SERVICE
         * ------------------------
         * 
         * Configure les propriétés de base du service Windows.
         * Ces propriétés définissent le comportement du service dans le Gestionnaire de services.
         */
        public DuoAuthService()
        {
            ServiceName = "DuoSigec4";        // Nom du service dans le Gestionnaire de services
            CanStop = true;                   // Le service peut être arrêté
            CanPauseAndContinue = false;      // Le service ne peut pas être mis en pause
            AutoLog = true;                   // Logging automatique vers l'EventLog Windows
        }

        /*
         * MÉTHODE : OnStart
         * -----------------
         * 
         * DESCRIPTION :
         * Méthode appelée lorsque le service Windows démarre.
         * Configure et démarre l'application ASP.NET Core.
         * 
         * PARAMÈTRES :
         * - args : Arguments de ligne de commande passés au service
         * 
         * ACTIONS :
         * 1. Configuration de l'application ASP.NET Core
         * 2. Configuration des services et dépendances
         * 3. Configuration des URLs d'écoute
         * 4. Démarrage de l'application
         * 5. Logging des événements de démarrage
         * 
         * GESTION D'ERREURS :
         * - Try/catch pour capturer les erreurs de démarrage
         * - Logging des erreurs dans l'EventLog Windows
         * - Arrêt propre du service en cas d'erreur
         */
        protected override void OnStart(string[] args)
        {
            try
            {
                /*
                 * CONFIGURATION DE L'APPLICATION
                 * -------------------------------
                 * 
                 * Création du builder avec des options personnalisées pour le service Windows.
                 * - ContentRootPath : Répertoire de base de l'application
                 * - Args : Arguments de ligne de commande
                 */
                var options = new WebApplicationOptions
                {
                    ContentRootPath = AppDomain.CurrentDomain.BaseDirectory,  // Répertoire de l'exécutable
                    Args = args                                                // Arguments du service
                };
                var builder = WebApplication.CreateBuilder(options);

                /*
                 * CONFIGURATION DU SERVICE WINDOWS
                 * ----------------------------------
                 * 
                 * Active le support des services Windows dans l'hôte ASP.NET Core.
                 * Cela permet à l'application de fonctionner correctement comme service.
                 */
                builder.Host.UseWindowsService();

                // Configuration des services
                builder.Services.AddControllers();
                builder.Services.AddEndpointsApiExplorer();

                // Configuration Duo Client Provider
                builder.Services.AddSingleton<IDuoClientProvider, DuoSigec4.Providers.DuoClientProvider>();

                // Configuration DataProtection
                var keysPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DuoSigec4", "keys");
                Directory.CreateDirectory(keysPath);
                builder.Services.AddDataProtection()
                    .PersistKeysToFileSystem(new DirectoryInfo(keysPath))
                    .SetApplicationName("DuoSigec4");

                // Services de session et cache
                builder.Services.AddDistributedMemoryCache();
                builder.Services.AddSession(options =>
                {
                    options.IdleTimeout = TimeSpan.FromMinutes(60);
                    options.Cookie.HttpOnly = true;
                    options.Cookie.IsEssential = true;
                    options.Cookie.SameSite = SameSiteMode.Lax;
                    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                    options.Cookie.Name = "DuoAuth.Session";
                });

                // Configuration CORS
                builder.Services.AddCors(options =>
                {
                    options.AddPolicy("AllowAll", policy =>
                    {
                        policy.AllowAnyOrigin()
                              .AllowAnyMethod()
                              .AllowAnyHeader();
                    });
                });

                // Services utilitaires
                builder.Services.AddHttpContextAccessor();
                builder.Services.AddSingleton<TempAuthStorage>();

                // Logging
                builder.Logging.AddConsole();
                builder.Logging.AddDebug();
                builder.Logging.AddEventLog();

                // Construire l'application
                var app = builder.Build();

                // Middleware pipeline
                if (app.Environment.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }

                // Test config Duo au démarrage
                try
                {
                    var duoProvider = app.Services.GetRequiredService<IDuoClientProvider>();
                    var client = duoProvider.GetDuoClient();
                    app.Logger.LogInformation("✅ Configuration Duo VALIDE");
                }
                catch (Exception ex)
                {
                    app.Logger.LogError("❌ Configuration Duo ERREUR: {Message}", ex.Message);
                }

                app.UseRouting();
                app.UseCors("AllowAll");
                app.UseSession();

                // Debug session middleware
                app.Use(async (context, next) =>
                {
                    try
                    {
                        if (context.Session != null && context.Session.IsAvailable)
                        {
                            app.Logger.LogDebug("Session ID: {SessionId}, Keys: {Keys}",
                                context.Session.Id, string.Join(", ", context.Session.Keys));
                        }
                        else
                        {
                            app.Logger.LogWarning("⚠️ La session n'est pas disponible pour cette requête.");
                        }
                    }
                    catch (InvalidOperationException ex)
                    {
                        app.Logger.LogWarning("⚠️ Erreur session: {Message}", ex.Message);
                    }
                    await next();
                });

                app.MapControllers();
                app.MapGet("/health", () => new { status = "healthy", timestamp = DateTime.UtcNow });

                // Configuration pour écouter sur tous les ports disponibles
                // Le service écoutera sur les ports configurés dans IIS
                // Commenté pour éviter les conflits de ports
                // app.Urls.Add("http://0.0.0.0:8080");
                // app.Urls.Add("https://0.0.0.0:8080");
                // app.Urls.Add("http://0.0.0.0:2012");
                // app.Urls.Add("https://0.0.0.0:2012");

                // Démarrer l'application
                _host = app;
                app.RunAsync();

                // Log de démarrage
                System.Diagnostics.EventLog.WriteEntry(ServiceName, "DuoSigec4 Service demarre avec succes", System.Diagnostics.EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry(ServiceName, $"Erreur lors du demarrage du service: {ex.Message}", System.Diagnostics.EventLogEntryType.Error);
                throw;
            }
        }

        protected override void OnStop()
        {
            try
            {
                _host?.StopAsync().Wait();
                System.Diagnostics.EventLog.WriteEntry(ServiceName, "DuoSigec4 Service arrete", System.Diagnostics.EventLogEntryType.Information);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog.WriteEntry(ServiceName, $"Erreur lors de l'arret du service: {ex.Message}", System.Diagnostics.EventLogEntryType.Error);
            }
        }

        protected override void OnShutdown()
        {
            OnStop();
        }
    }
}
