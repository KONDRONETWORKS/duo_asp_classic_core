/*
 * ========================================================================
 * FICHIER : Controllers/AuthController.cs
 * ========================================================================
 * 
 * DESCRIPTION :
 * ------------
 * Ce contrôleur gère les opérations d'authentification de base pour l'intégration
 * avec les applications ASP Classic. Il fournit des endpoints pour vérifier
 * l'état d'authentification et initialiser le processus d'authentification Duo.
 * 
 * FONCTIONNALITÉS PRINCIPALES :
 * -----------------------------
 * 1. GET /api/Auth - Configuration et informations Duo
 * 2. GET /api/Auth/check - Vérification de l'état d'authentification
 * 3. POST /api/Auth/init - Initialisation du processus d'authentification
 * 4. GET /api/Auth/duo-url - Génération de l'URL de redirection Duo
 * 5. POST /api/Auth/logout - Déconnexion de l'utilisateur
 * 
 * INTÉGRATION ASP CLASSIC :
 * -------------------------
 * Ce contrôleur est appelé par les applications ASP Classic pour :
 * - Vérifier si un utilisateur est déjà authentifié
 * - Initialiser le processus d'authentification MFA
 * - Obtenir l'URL de redirection vers Duo
 * - Gérer la déconnexion
 * 
 * SÉCURITÉ :
 * ----------
 * - Utilise les sessions pour maintenir l'état d'authentification
 * - Validation des paramètres d'entrée
 * - Gestion sécurisée des états (state) pour prévenir les attaques CSRF
 * 
 * ========================================================================
 */

using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using System.Text.Json;

namespace DuoSigec4.Controllers
{
    /*
     * CONTRÔLEUR D'AUTHENTIFICATION
     * -----------------------------
     * 
     * Route de base : /api/Auth
     * Hérite de ControllerBase pour les API (pas de support des vues)
     * 
     * ENDPOINTS DISPONIBLES :
     * - GET /api/Auth - Configuration Duo
     * - GET /api/Auth/check - Vérification authentification
     * - POST /api/Auth/init - Initialisation authentification
     * - GET /api/Auth/duo-url - URL de redirection Duo
     * - POST /api/Auth/logout - Déconnexion
     */
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        /*
         * INJECTION DE DÉPENDANCES
         * ------------------------
         * 
         * - IConfiguration : Accès aux paramètres de configuration (appsettings.json)
         * - IHttpContextAccessor : Accès au contexte HTTP pour les sessions
         */
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        /*
         * CONSTRUCTEUR
         * ------------
         * 
         * Injection des dépendances nécessaires pour le contrôleur.
         * Ces services sont automatiquement fournis par le conteneur DI d'ASP.NET Core.
         */
        public AuthController(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _configuration = configuration;
            _httpContextAccessor = httpContextAccessor;
        }

        /*
         * ENDPOINT : GET /api/Auth
         * ------------------------
         * 
         * DESCRIPTION :
         * Retourne les informations de configuration Duo (sans les données sensibles).
         * Utilisé pour vérifier que la configuration est correcte.
         * 
         * RÉPONSE :
         * - ClientId : Identifiant du client Duo
         * - ClientIdLength : Longueur du ClientId (pour validation)
         * - ApiHost : Hôte de l'API Duo
         * - HasClientId : Indique si le ClientId est configuré
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic pour vérifier la configuration.
         */
        [HttpGet]
        public IActionResult GetConfig()
        {
            var duoConfig = _configuration.GetSection("Duo");
            return Ok(new {
                ClientId = duoConfig["ClientId"],
                ClientIdLength = duoConfig["ClientId"]?.Length,
                ApiHost = duoConfig["ApiHost"],
                HasClientId = !string.IsNullOrEmpty(duoConfig["ClientId"])
            });
        }

        /*
         * ENDPOINT : GET /api/Auth/check
         * ------------------------------
         * 
         * DESCRIPTION :
         * Vérifie si l'utilisateur spécifié est authentifié via Duo.
         * Utilise les données de session pour déterminer l'état d'authentification.
         * 
         * PARAMÈTRES :
         * - username (query) : Nom d'utilisateur à vérifier
         * 
         * VÉRIFICATIONS :
         * - Session active avec données d'authentification
         * - Nom d'utilisateur correspondant
         * - Authentification Duo validée
         * 
         * RÉPONSE :
         * - Authenticated : true/false
         * - Username : Nom d'utilisateur vérifié
         * - Timestamp : Horodatage de la vérification
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic pour vérifier l'état d'authentification
         * avant d'autoriser l'accès aux ressources protégées.
         */
        [HttpGet("check")]
        public IActionResult CheckAuth([FromQuery] string username)
        {
            try
            {
                var session = _httpContextAccessor.HttpContext.Session;
                var sessionUsername = session.GetString("_Username");
                var sessionState = session.GetString("_State");
                var duoAuthenticated = session.GetString("_DuoAuthenticated");

                // Vérifier si l'utilisateur est authentifié via Duo
                if (!string.IsNullOrEmpty(duoAuthenticated) && 
                    !string.IsNullOrEmpty(sessionUsername) && 
                    sessionUsername.Equals(username, StringComparison.OrdinalIgnoreCase))
                {
                    return Ok(new
                    {
                        Authenticated = true,
                        Username = sessionUsername,
                        Timestamp = DateTime.UtcNow
                    });
                }

                return Ok(new
                {
                    Authenticated = false,
                    Username = username,
                    Message = "Utilisateur non authentifié via Duo"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    Error = "Erreur lors de la vérification d'authentification",
                    Details = ex.Message
                });
            }
        }

        /*
         * ENDPOINT : POST /api/Auth/init
         * ------------------------------
         * 
         * DESCRIPTION :
         * Démarre le processus d'authentification Duo pour un utilisateur.
         * Initialise la session avec les données nécessaires et génère un état unique.
         * 
         * PARAMÈTRES :
         * - request (body) : Objet InitAuthRequest contenant le nom d'utilisateur
         * 
         * ACTIONS :
         * - Stocke le nom d'utilisateur en session
         * - Marque la session comme provenant d'une application legacy
         * - Génère un état unique (state) pour la sécurité CSRF
         * 
         * RÉPONSE :
         * - Success : true/false
         * - Username : Nom d'utilisateur initialisé
         * - State : État unique généré
         * - Message : Message de confirmation
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic pour initier l'authentification MFA.
         * Doit être suivi d'un appel à /api/Auth/duo-url pour obtenir l'URL de redirection.
         */
        [HttpPost("init")]
        public IActionResult InitAuth([FromBody] InitAuthRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Username))
                {
                    return BadRequest(new { Error = "Nom d'utilisateur requis" });
                }

                var session = _httpContextAccessor.HttpContext.Session;
                
                // Stocker le nom d'utilisateur en session
                session.SetString("_Username", request.Username);
                session.SetString("_LegacyApp", "true");

                // Générer un état unique pour cette session
                var state = Guid.NewGuid().ToString();
                session.SetString("_State", state);

                return Ok(new
                {
                    Success = true,
                    Username = request.Username,
                    State = state,
                    Message = "Authentification initialisée, rediriger vers Duo"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    Error = "Erreur lors de l'initialisation de l'authentification",
                    Details = ex.Message
                });
            }
        }

        /*
         * ENDPOINT : GET /api/Auth/duo-url
         * ---------------------------------
         * 
         * DESCRIPTION :
         * Génère l'URL de redirection vers Duo pour l'authentification.
         * Construit l'URL OAuth avec tous les paramètres nécessaires.
         * 
         * PARAMÈTRES :
         * - username (query) : Nom d'utilisateur
         * - state (query) : État unique généré par /api/Auth/init
         * 
         * VÉRIFICATIONS :
         * - Validation de l'état (state) pour la sécurité CSRF
         * - Correspondance du nom d'utilisateur avec la session
         * 
         * CONSTRUCTION URL :
         * - Hôte : api-{ApiHost}/oauth/v1/authorize
         * - Client ID : Paramètre client_id
         * - Redirect URI : URL de callback configurée
         * - Response Type : code (OAuth Authorization Code)
         * - Scope : openid
         * - State : État unique pour la sécurité
         * 
         * RÉPONSE :
         * - Success : true/false
         * - DuoUrl : URL complète de redirection vers Duo
         * - Username : Nom d'utilisateur
         * - State : État validé
         * - Message : Message de confirmation
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic après /api/Auth/init
         * pour obtenir l'URL de redirection vers Duo.
         */
        [HttpGet("duo-url")]
        public IActionResult GetDuoUrl([FromQuery] string username, [FromQuery] string state)
        {
            try
            {
                if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(state))
                {
                    return BadRequest(new { Error = "Nom d'utilisateur et état requis" });
                }

                var session = _httpContextAccessor.HttpContext.Session;
                var sessionUsername = session.GetString("_Username");
                var sessionState = session.GetString("_State");

                // Vérifier que l'état et l'utilisateur correspondent
                if (sessionUsername != username || sessionState != state)
                {
                    return BadRequest(new { Error = "État ou utilisateur invalide" });
                }

                // Construire l'URL de redirection vers Duo
                var duoUrl = $"https://api-{_configuration["Duo:ApiHost"]}/oauth/v1/authorize?" +
                            $"client_id={Uri.EscapeDataString(_configuration["Duo:ClientId"])}&" +
                            $"redirect_uri={Uri.EscapeDataString(_configuration["Duo:RedirectUri"])}&" +
                            $"response_type=code&" +
                            $"scope=openid&" +
                            $"state={Uri.EscapeDataString(state)}";

                return Ok(new
                {
                    Success = true,
                    DuoUrl = duoUrl,
                    Username = username,
                    State = state,
                    Message = "URL de redirection vers Duo générée"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    Error = "Erreur lors de la génération de l'URL Duo",
                    Details = ex.Message
                });
            }
        }

        /*
         * ENDPOINT : POST /api/Auth/logout
         * ---------------------------------
         * 
         * DESCRIPTION :
         * Déconnecte l'utilisateur en effaçant toutes les données de session.
         * Invalide l'authentification et nettoie l'état de la session.
         * 
         * ACTIONS :
         * - Efface toutes les données de session
         * - Invalide l'authentification Duo
         * - Supprime les informations utilisateur
         * 
         * RÉPONSE :
         * - Success : true/false
         * - Message : Message de confirmation
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic pour la déconnexion de l'utilisateur.
         * Doit être appelé lorsque l'utilisateur se déconnecte de l'application legacy.
         */
        [HttpPost("logout")]
        public IActionResult Logout()
        {
            try
            {
                var session = _httpContextAccessor.HttpContext.Session;
                session.Clear();

                return Ok(new
                {
                    Success = true,
                    Message = "Utilisateur déconnecté"
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new
                {
                    Error = "Erreur lors de la déconnexion",
                    Details = ex.Message
                });
            }
        }
    }

    /*
     * ========================================================================
     * MODÈLE DE DONNÉES : InitAuthRequest
     * ========================================================================
     * 
     * DESCRIPTION :
     * ------------
     * Modèle de données pour les requêtes d'initialisation d'authentification.
     * Utilisé par l'endpoint POST /api/Auth/init.
     * 
     * PROPRIÉTÉS :
     * ------------
     * - Username : Nom d'utilisateur à authentifier (requis)
     * 
     * VALIDATION :
     * ------------
     * - Username ne doit pas être null ou vide
     * - Validation effectuée dans le contrôleur
     * 
     * UTILISATION :
     * -------------
     * Envoyé dans le corps de la requête POST vers /api/Auth/init
     * par les applications ASP Classic.
     * 
     * ========================================================================
     */
    public class InitAuthRequest
    {
        /// <summary>
        /// Nom d'utilisateur à authentifier via Duo
        /// </summary>
        public string Username { get; set; }
    }
} 