/*
 * ========================================================================
 * FICHIER : Controllers/DuoAuthController.cs
 * ========================================================================
 * 
 * DESCRIPTION :
 * ------------
 * Ce contrôleur gère l'authentification Duo complète en utilisant les
 * classes officielles de Duo Security. Il implémente le flux OAuth 2.0
 * pour l'authentification multi-facteurs (MFA).
 * 
 * FONCTIONNALITÉS PRINCIPALES :
 * -----------------------------
 * 1. GET /api/DuoAuth/duo-auth - Démarrage de l'authentification Duo
 * 2. GET /api/DuoAuth/callback - Callback OAuth de Duo
 * 3. GET /api/DuoAuth/validate-token - Validation des tokens d'authentification
 * 
 * FLUX D'AUTHENTIFICATION :
 * -------------------------
 * 1. Application ASP Classic → /api/DuoAuth/duo-auth
 * 2. Redirection vers Duo Security
 * 3. Utilisateur authentifie via Duo
 * 4. Duo redirige vers /api/DuoAuth/callback
 * 5. Application valide le token et authentifie l'utilisateur
 * 6. Application ASP Classic peut vérifier l'état via /api/DuoAuth/validate-token
 * 
 * SÉCURITÉ :
 * ----------
 * - Utilise les classes officielles Duo Security
 * - Validation des tokens JWT
 * - Gestion sécurisée des sessions
 * - Protection contre les attaques CSRF
 * 
 * INTÉGRATION :
 * -------------
 * - Compatible avec les applications ASP Classic
 * - Support des redirections personnalisées
 * - Gestion des erreurs d'authentification
 * 
 * ========================================================================
 */

using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using DuoSigec4.Services;
using DuoSigec4.Providers;

namespace DuoSigec4.Controllers
{
    /*
     * CONTRÔLEUR D'AUTHENTIFICATION DUO
     * ----------------------------------
     * 
     * Route de base : /api/DuoAuth
     * Utilise les classes officielles de Duo Security pour l'authentification MFA.
     * 
     * ENDPOINTS DISPONIBLES :
     * - GET /api/DuoAuth/duo-auth - Démarrage authentification
     * - GET /api/DuoAuth/callback - Callback OAuth Duo
     * - GET /api/DuoAuth/validate-token - Validation token
     * 
     * DÉPENDANCES :
     * - IDuoClientProvider : Client Duo Security
     * - IHttpContextAccessor : Accès au contexte HTTP
     * - IConfiguration : Configuration de l'application
     * - ILogger : Logging des opérations
     * - TempAuthStorage : Stockage temporaire des données d'auth
     */
    [ApiController]
    [Route("api/[controller]")]
    public class DuoAuthController : ControllerBase
    {
        /*
         * INJECTION DE DÉPENDANCES
         * ------------------------
         * 
         * - IDuoClientProvider : Client Duo Security pour l'authentification
         * - IHttpContextAccessor : Accès au contexte HTTP et aux sessions
         * - IConfiguration : Configuration de l'application (appsettings.json)
         * - ILogger : Système de logging pour le débogage et monitoring
         * - TempAuthStorage : Stockage temporaire des données d'authentification
         */
        private readonly IDuoClientProvider _duoClientProvider;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;
        private readonly ILogger<DuoAuthController> _logger;
        private readonly TempAuthStorage _tempAuthStorage;

        /*
         * CONSTRUCTEUR
         * ------------
         * 
         * Injection des dépendances nécessaires pour le contrôleur.
         * Toutes les dépendances sont automatiquement fournies par le conteneur DI.
         */
        public DuoAuthController(
            IDuoClientProvider duoClientProvider, 
            IHttpContextAccessor httpContextAccessor, 
            IConfiguration configuration,
            ILogger<DuoAuthController> logger,
            TempAuthStorage tempAuthStorage)
        {
            _duoClientProvider = duoClientProvider;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
            _logger = logger;
            _tempAuthStorage = tempAuthStorage;
        }

        /*
         * ENDPOINT : GET /api/DuoAuth/duo-auth
         * -------------------------------------
         * 
         * DESCRIPTION :
         * Point d'entrée principal pour l'authentification Duo depuis les applications ASP Classic.
         * Initialise la session et redirige l'utilisateur vers Duo Security pour l'authentification MFA.
         * 
         * PARAMÈTRES :
         * - username (query) : Nom d'utilisateur à authentifier (requis)
         * - returnUrl (query) : URL de retour après authentification (optionnel)
         * 
         * ACTIONS :
         * - Validation du nom d'utilisateur
         * - Initialisation de la session avec les données utilisateur
         * - Génération d'un état unique (state) pour la sécurité CSRF
         * - Stockage des données temporaires d'authentification
         * - Génération de l'URL d'authentification Duo
         * - Redirection vers Duo Security
         * 
         * SÉCURITÉ :
         * - Validation des paramètres d'entrée
         * - Génération d'un état unique pour chaque session
         * - Stockage sécurisé des données temporaires
         * 
         * RÉPONSE :
         * - Redirection HTTP 302 vers Duo Security
         * - Ou erreur HTTP 400 si paramètres invalides
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic pour initier l'authentification MFA.
         * L'utilisateur sera redirigé vers Duo pour compléter l'authentification.
         */
        [HttpGet("duo-auth")]
        public IActionResult DuoAuth([FromQuery] string username, [FromQuery] string? returnUrl = null)
        {
            try
            {
                if (string.IsNullOrEmpty(username))
                {
                    _logger.LogWarning("Tentative d'authentification sans nom d'utilisateur");
                    return BadRequest(new { error = "Nom d'utilisateur requis" });
                }

                var session = _httpContextAccessor.HttpContext.Session;
                
                // Stocker le nom d'utilisateur en session
                session.SetString("_Username", username);
                session.SetString("_LegacyApp", "true");

                // Générer un état unique pour cette session
                var state = Guid.NewGuid().ToString();
                session.SetString("_State", state);

                // Stocker les données temporaires
                var authData = new AuthData
                {
                    Username = username,
                    State = state,
                    ReturnUrl = returnUrl ?? string.Empty
                };
                _tempAuthStorage.Store(state, authData);

                // Utiliser la méthode officielle de Duo pour créer l'URL d'authentification
                // Si returnUrl est fourni, l'utiliser comme base pour la RedirectUri
                string redirectUri;
                
                _logger.LogInformation("ReturnUrl reçu: '{ReturnUrl}'", returnUrl ?? "NULL");
                
                if (!string.IsNullOrWhiteSpace(returnUrl))
                {
                    // Utiliser directement le returnUrl comme RedirectUri
                    // Duo redirigera directement vers l'application ASP Classic
                    redirectUri = returnUrl;
                    _logger.LogInformation("RedirectUri utilisée directement: '{RedirectUri}'", redirectUri);
                }
                else
                {
                    // Utiliser la RedirectUri par défaut de la configuration
                    redirectUri = _duoClientProvider.GetRedirectUri();
                    _logger.LogInformation("Utilisation de la RedirectUri par défaut: '{RedirectUri}'", redirectUri);
                }
                
                var duoClient = _duoClientProvider.GetDuoClient(redirectUri);
                var authUrl = duoClient.GenerateAuthUri(username, state);
                
                _logger.LogInformation("Redirection vers Duo pour l'utilisateur: {Username}", username);
                _logger.LogDebug("URL Duo: {AuthUrl}", authUrl);

                // Rediriger directement vers Duo
                return Redirect(authUrl);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de l'initialisation de l'authentification Duo");
                return StatusCode(500, new { error = "Erreur lors de l'initialisation de l'authentification Duo" });
            }
        }


        /*
         * ENDPOINT : GET /api/DuoAuth/validate-token
         * -------------------------------------------
         * 
         * DESCRIPTION :
         * Valide un token JWT d'authentification Duo en utilisant les utilitaires officiels de Duo Security.
         * Ce endpoint permet de vérifier la validité d'un token sans effectuer d'authentification complète.
         * 
         * PARAMÈTRES :
         * - token (query) : Token JWT à valider (requis)
         * 
         * VALIDATION :
         * - Utilise les classes officielles de Duo Security
         * - Vérifie la signature du token
         * - Valide l'expiration du token
         * - Contrôle l'émetteur du token
         * 
         * RÉPONSE :
         * - Success : true/false selon la validité du token
         * - Claims : Informations extraites du token si valide
         * - Error : Message d'erreur si le token est invalide
         * 
         * UTILISATION :
         * Appelé par les applications ASP Classic pour vérifier la validité d'un token
         * d'authentification Duo avant d'autoriser l'accès aux ressources protégées.
         */
        [HttpGet("validate-token")]
        public IActionResult ValidateToken([FromQuery] string token)
        {
            try
            {
                if (string.IsNullOrEmpty(token))
                {
                    return BadRequest(new { error = "Token requis" });
                }

                // Utiliser directement les utilitaires officiels de Duo pour décoder le token
                var decodedToken = DuoSigec4.Utils.DecodeToken(token);
                
                if (decodedToken != null)
                {
                    return Ok(new
                    {
                        success = true,
                        username = decodedToken.Username,
                        expiresAt = decodedToken.Exp,
                        message = "Token valide"
                    });
                }
                else
                {
                    return BadRequest(new
                    {
                        success = false,
                        error = "Token invalide ou malformé",
                        message = "Impossible de décoder le token"
                    });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Erreur lors de la validation du token");
                return StatusCode(500, new { error = "Erreur lors de la validation du token" });
            }
        }
    }
}