# Guide de Déploiement DuoSigec4 pour IIS

## Vue d'ensemble
Ce guide explique comment déployer l'application DuoSigec4 sur IIS pour qu'elle soit accessible via `https://test.cafecacao.ci:2012`.

## Prérequis

### 1. Serveur Windows avec IIS
- Windows Server 2016 ou plus récent
- IIS 10.0 ou plus récent
- .NET 6.0 Runtime installé

### 2. Modules IIS requis
- ASP.NET Core Hosting Bundle (inclut le runtime .NET 6.0)
- URL Rewrite Module (pour les redirections HTTPS)

### 3. Certificat SSL
- Certificat SSL valide pour `test.cafecacao.ci`
- Installé dans le magasin de certificats Windows

## Étapes de Déploiement

### 1. Préparation de l'Application

#### Compilation pour la Production
```bash
# Dans le répertoire du projet
dotnet publish -c Release -o ./publish
```

#### Vérification des Fichiers
Assurez-vous que les fichiers suivants sont présents dans le dossier `publish` :
- `DuoSigec4.dll`
- `web.config`
- `appsettings.json`
- `appsettings.Production.json`
- Tous les fichiers de dépendances

### 2. Configuration IIS

#### Création du Site Web
1. Ouvrir le Gestionnaire des services Internet (IIS)
2. Clic droit sur "Sites" → "Ajouter un site web"
3. Configuration :
   - **Nom du site** : DuoSigec4
   - **Chemin physique** : `C:\inetpub\wwwroot\DuoSigec4` (ou votre chemin)
   - **Type** : https
   - **Adresse IP** : Toutes les adresses IP non assignées
   - **Port** : 2012
   - **Nom d'hôte** : test.cafecacao.ci
   - **Certificat SSL** : Sélectionner votre certificat

#### Configuration du Pool d'Applications
1. Créer un nouveau pool d'applications :
   - **Nom** : DuoSigec4
   - **Version .NET** : Pas de code managé
   - **Mode de pipeline** : Intégré
   - **Identité** : ApplicationPoolIdentity

2. Assigner le site au pool d'applications

### 3. Configuration des Permissions

#### Dossier de l'Application
```cmd
# Donner les permissions au pool d'applications
icacls "C:\inetpub\wwwroot\DuoSigec4" /grant "IIS AppPool\DuoSigec4:(OI)(CI)F"
```

#### Dossier des Logs
```cmd
# Créer le dossier des logs
mkdir "C:\inetpub\wwwroot\DuoSigec4\logs"
icacls "C:\inetpub\wwwroot\DuoSigec4\logs" /grant "IIS AppPool\DuoSigec4:(OI)(CI)F"
```

### 4. Configuration des Variables d'Environnement

Dans le fichier `web.config`, les variables d'environnement sont déjà configurées :
```xml
<environmentVariables>
    <environmentVariable name="ASPNETCORE_ENVIRONMENT" value="Production" />
    <environmentVariable name="ASPNETCORE_URLS" value="https://+:2012" />
</environmentVariables>
```

### 5. Configuration du Pare-feu

#### Règles de Pare-feu Windows
```cmd
# Autoriser le port 2012 pour HTTPS
netsh advfirewall firewall add rule name="DuoSigec4 HTTPS" dir=in action=allow protocol=TCP localport=2012
```

### 6. Test de l'Application

#### Vérification des Endpoints
1. **Health Check** : `https://test.cafecacao.ci:2012/health`
2. **Authentification Duo** : `https://test.cafecacao.ci:2012/api/duoauth/duo-auth?username=test`
3. **Callback** : `https://test.cafecacao.ci:2012`

#### Logs de Débogage
Les logs sont disponibles dans :
- `C:\inetpub\wwwroot\DuoSigec4\logs\stdout_*.log`
- Journaux des événements Windows (Application)

### 7. Intégration avec l'Application Sigec4

#### URL d'Authentification
Pour intégrer avec votre application ASP Classic, utilisez :
```
https://test.cafecacao.ci:2012/api/duoauth/duo-auth?username={USERNAME}&returnUrl={RETURN_URL}
```

#### URL de Callback
L'URL de callback configurée dans Duo doit être :
```
https://test.cafecacao.ci:2012
```

## Dépannage

### Problèmes Courants

#### 1. Erreur 500.30 - Application ASP.NET Core ne démarre pas
- Vérifier que .NET 6.0 Runtime est installé
- Vérifier les permissions sur le dossier de l'application
- Consulter les logs dans `logs\stdout_*.log`

#### 2. Erreur de Certificat SSL
- Vérifier que le certificat est installé et valide
- Vérifier que le certificat correspond au nom de domaine
- Redémarrer IIS après l'installation du certificat

#### 3. Erreur de Connexion Duo
- Vérifier la configuration dans `appsettings.Production.json`
- Vérifier que l'URL de callback est correctement configurée dans Duo
- Vérifier la connectivité réseau vers `api-a322db2c.duosecurity.com`

### Commandes de Diagnostic

```cmd
# Vérifier le statut du site
iisreset /status

# Redémarrer IIS
iisreset

# Vérifier les processus .NET
tasklist /fi "imagename eq dotnet.exe"

# Vérifier les ports en écoute
netstat -an | findstr :2012
```

## Sécurité

### Recommandations
1. **Certificat SSL** : Utiliser un certificat valide et à jour
2. **Permissions** : Limiter les permissions au minimum nécessaire
3. **Logs** : Surveiller régulièrement les logs pour détecter les anomalies
4. **Mise à jour** : Maintenir l'application et le serveur à jour

### Configuration CORS
L'application est configurée pour accepter toutes les origines en développement. Pour la production, considérez de restreindre les origines autorisées.

## Maintenance

### Sauvegarde
- Sauvegarder régulièrement le dossier de l'application
- Sauvegarder la configuration IIS
- Sauvegarder les certificats SSL

### Mise à jour
1. Arrêter le site dans IIS
2. Remplacer les fichiers de l'application
3. Redémarrer le site
4. Vérifier le fonctionnement

## Support

Pour toute question ou problème :
1. Consulter les logs d'application
2. Vérifier la configuration IIS
3. Tester la connectivité réseau
4. Contacter l'équipe de développement
