# uninstall-service.ps1
# Désinstallation du service Windows DuoSigec4

param(
    [string]$ServiceName = "DuoSigec4",
    [string]$PublishPath = "C:\inetpub\wwwroot\DuoSigec4"
)

Write-Host "=== Désinstallation Service DuoSigec4 ===" -ForegroundColor Red

# Vérifier les privilèges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit être exécuté en tant qu'administrateur."
    exit 1
}

# 1. Arrêt et suppression du service
Write-Host "`n1. Suppression du service..." -ForegroundColor Yellow
if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    Stop-Service -Name $ServiceName -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName
    Write-Host "✅ Service supprimé" -ForegroundColor Green
} else {
    Write-Host "✅ Service non trouvé" -ForegroundColor Green
}

# 2. Suppression des règles de pare-feu
Write-Host "`n2. Suppression des règles de pare-feu..." -ForegroundColor Yellow
$ports = @(9000, 9001, 8080, 2012)
foreach ($port in $ports) {
    $ruleName = "$ServiceName Port $port"
    if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -DisplayName $ruleName
        Write-Host "  Règle port $port supprimée" -ForegroundColor Cyan
    }
}
Write-Host "✅ Règles de pare-feu supprimées" -ForegroundColor Green

# 3. Suppression du dossier de publication
Write-Host "`n3. Suppression des fichiers..." -ForegroundColor Yellow
if (Test-Path $PublishPath) {
    Remove-Item -Path $PublishPath -Recurse -Force
    Write-Host "✅ Fichiers supprimés" -ForegroundColor Green
} else {
    Write-Host "✅ Aucun fichier à supprimer" -ForegroundColor Green
}

Write-Host "`n=== Désinstallation terminée ===" -ForegroundColor Red
