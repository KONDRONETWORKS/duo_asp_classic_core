using DuoUniversal;

namespace DuoSigec4
{
    /// <summary>
    /// Interface pour fournir une instance configurée de DuoUniversal.Client
    /// </summary>
    public interface IDuoClientProvider
    {
        /// <summary>
        /// Crée et retourne une instance configurée de DuoUniversal.Client
        /// </summary>
        /// <returns>Instance configurée de DuoUniversal.Client</returns>
        DuoUniversal.Client GetDuoClient();

        /// <summary>
        /// Crée et retourne une instance configurée de DuoUniversal.Client avec une RedirectUri personnalisée
        /// </summary>
        /// <param name="customRedirectUri">URI de redirection personnalisée</param>
        /// <returns>Instance configurée de DuoUniversal.Client</returns>
        DuoUniversal.Client GetDuoClient(string customRedirectUri);

        /// <summary>
        /// Retourne le Client ID configuré
        /// </summary>
        /// <returns>Client ID</returns>
        string GetClientId();

        /// <summary>
        /// Retourne l'API Host configuré
        /// </summary>
        /// <returns>API Host</returns>
        string GetApiHost();

        /// <summary>
        /// Retourne l'URI de redirection configuré
        /// </summary>
        /// <returns>URI de redirection</returns>
        string GetRedirectUri();
    }
}
