/*
 * ========================================================================
 * FICHIER : Program.cs
 * ========================================================================
 * 
 * DESCRIPTION :
 * ------------
 * Ce fichier est le point d'entrée principal de l'application DuoSigec4.
 * Il configure et démarre l'application ASP.NET Core pour l'authentification Duo.
 * 
 * FONCTIONNALITÉS PRINCIPALES :
 * -----------------------------
 * 1. Configuration de l'injection de dépendances
 * 2. Configuration des services (sessions, CORS, logging)
 * 3. Configuration de la protection des données
 * 4. Configuration du middleware pipeline
 * 5. Configuration des URLs d'écoute
 * 6. Support du mode service Windows
 * 
 * UTILISATION :
 * -------------
 * - Mode développement : dotnet run
 * - Mode service : dotnet DuoSigec4.dll --service
 * - Mode production : Exécuté par IIS via web.config
 * 
 * PORTS CONFIGURÉS :
 * ------------------
 * - HTTP : 8080 (pour développement et tests)
 * - HTTPS : 8081 (nécessite certificat SSL)
 * 
 * INTÉGRATION :
 * -------------
 * - Compatible avec IIS via ASP.NET Core Module
 * - Compatible avec applications ASP Classic
 * - Support des services Windows
 * 
 * ========================================================================
 */

using System;
using System.IO;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using DuoSigec4.Services;
using DuoSigec4.Providers;
using Microsoft.AspNetCore.DataProtection;
using DuoSigec4;
using System.ServiceProcess;

/*
 * ========================================================================
 * DÉTECTION DU MODE SERVICE WINDOWS
 * ========================================================================
 * 
 * Cette section vérifie si l'application doit être exécutée comme service Windows.
 * Si l'argument --service est fourni, l'application se lance en mode service.
 * 
 * UTILISATION :
 * - Installation service : sc create DuoAuth binPath="C:\path\to\DuoSigec4.exe --service"
 * - Démarrage service : sc start DuoAuth
 * - Arrêt service : sc stop DuoAuth
 * 
 * ========================================================================
 */
if (args.Length > 0 && args[0] == "--service")
{
    // Exécuter comme service Windows - utilise DuoAuthService.cs
    ServiceBase.Run(new DuoAuthService());
    return;
}

/*
 * ========================================================================
 * CONFIGURATION DE L'APPLICATION WEB
 * ========================================================================
 * 
 * Cette section configure l'application ASP.NET Core avec tous les services
 * nécessaires pour l'authentification Duo et l'intégration avec ASP Classic.
 * 
 * ========================================================================
 */
var builder = WebApplication.CreateBuilder(args);

/*
 * SERVICES DE BASE ASP.NET CORE
 * -----------------------------
 * - AddControllers : Active les contrôleurs API
 * - AddEndpointsApiExplorer : Active l'exploration des endpoints
 */
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

/*
 * CONFIGURATION DU CLIENT DUO
 * ---------------------------
 * - IDuoClientProvider : Interface pour l'injection de dépendance
 * - DuoClientProvider : Implémentation concrète du client Duo
 * - Singleton : Une seule instance partagée dans toute l'application
 */
builder.Services.AddSingleton<IDuoClientProvider, DuoSigec4.Providers.DuoClientProvider>();

/*
 * CONFIGURATION DE LA PROTECTION DES DONNÉES
 * ------------------------------------------
 * 
 * Cette section configure la protection des données pour sécuriser les tokens
 * et les informations sensibles de l'authentification Duo.
 * 
 * FONCTIONNALITÉS :
 * - PersistKeysToFileSystem : Sauvegarde les clés de chiffrement sur disque
 * - SetApplicationName : Identifie l'application pour la protection des données
 * - Emplacement : %APPDATA%\DuoSigec4\keys\
 * 
 * SÉCURITÉ :
 * - Les clés sont stockées dans un dossier sécurisé
 * - Chiffrement automatique des données sensibles
 * - Compatible avec le déploiement en cluster
 */
var keysPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DuoSigec4", "keys");
Directory.CreateDirectory(keysPath);
builder.Services.AddDataProtection()
    .PersistKeysToFileSystem(new DirectoryInfo(keysPath))
    .SetApplicationName("DuoSigec4");

/*
 * CONFIGURATION DES SESSIONS ET CACHE
 * -----------------------------------
 * 
 * Cette section configure le système de sessions pour maintenir l'état
 * de l'authentification Duo entre les requêtes.
 * 
 * FONCTIONNALITÉS :
 * - DistributedMemoryCache : Cache en mémoire pour les sessions
 * - Session : Gestion des sessions utilisateur
 * - Cookie sécurisé : Protection contre les attaques XSS
 * 
 * PARAMÈTRES DE SÉCURITÉ :
 * - IdleTimeout : 60 minutes d'inactivité
 * - HttpOnly : Cookie non accessible via JavaScript
 * - SameSite : Protection contre les attaques CSRF
 * - SecurePolicy : Compatible avec HTTP et HTTPS
 */
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(60);  // Session expire après 1h d'inactivité
    options.Cookie.HttpOnly = true;                  // Protection XSS
    options.Cookie.IsEssential = true;               // Cookie essentiel pour l'application
    options.Cookie.SameSite = SameSiteMode.Lax;      // Protection CSRF
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest; // Compatible avec IIS
    options.Cookie.Name = "DuoAuth.Session";         // Nom du cookie de session
});

/*
 * CONFIGURATION CORS (Cross-Origin Resource Sharing)
 * --------------------------------------------------
 * 
 * Cette section configure CORS pour permettre les requêtes depuis des domaines
 * différents, notamment pour l'intégration avec les applications ASP Classic.
 * 
 * POLITIQUE "AllowAll" :
 * - AllowAnyOrigin : Accepte les requêtes de n'importe quel domaine
 * - AllowAnyMethod : Accepte toutes les méthodes HTTP (GET, POST, etc.)
 * - AllowAnyHeader : Accepte tous les en-têtes HTTP
 * 
 * SÉCURITÉ : En production, restreindre les origines autorisées
 */
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()      // ⚠️ En production, spécifier les domaines autorisés
              .AllowAnyMethod()      // GET, POST, PUT, DELETE, etc.
              .AllowAnyHeader();     // Tous les en-têtes HTTP
    });
});

/*
 * SERVICES UTILITAIRES
 * --------------------
 * 
 * - HttpContextAccessor : Accès au contexte HTTP depuis les services
 * - TempAuthStorage : Stockage temporaire des données d'authentification
 */
builder.Services.AddHttpContextAccessor();
builder.Services.AddSingleton<TempAuthStorage>();

/*
 * CONFIGURATION DU LOGGING
 * -------------------------
 * 
 * - Console : Logs dans la console (développement)
 * - Debug : Logs de débogage (développement uniquement)
 * 
 * EN PRODUCTION : Ajouter des providers de logs (fichier, base de données, etc.)
 */
builder.Logging.AddConsole();
builder.Logging.AddDebug();

/*
 * ========================================================================
 * CONSTRUCTION DE L'APPLICATION ET PIPELINE MIDDLEWARE
 * ========================================================================
 * 
 * Cette section construit l'application et configure le pipeline de middleware
 * qui traite les requêtes HTTP dans l'ordre défini.
 * 
 * ========================================================================
 */
var app = builder.Build();

/*
 * PIPELINE MIDDLEWARE - ORDRE IMPORTANT
 * -------------------------------------
 * 
 * L'ordre des middlewares est crucial car ils s'exécutent dans l'ordre
 * de configuration pour les requêtes entrantes et dans l'ordre inverse
 * pour les réponses sortantes.
 */
if (app.Environment.IsDevelopment())
{
    // Page d'erreur détaillée en développement uniquement
    app.UseDeveloperExceptionPage();
}

/*
 * VALIDATION DE LA CONFIGURATION DUO AU DÉMARRAGE
 * ------------------------------------------------
 * 
 * Cette section teste la configuration Duo au démarrage de l'application
 * pour s'assurer que tous les paramètres sont corrects.
 * 
 * VÉRIFICATIONS :
 * - ClientId valide
 * - ClientSecret valide
 * - ApiHost accessible
 * - RedirectUri configuré
 */
try
{
    var duoProvider = app.Services.GetRequiredService<IDuoClientProvider>();
    var client = duoProvider.GetDuoClient();
    app.Logger.LogInformation("✅ Configuration Duo VALIDE");
}
catch (Exception ex)
{
    app.Logger.LogError("❌ Configuration Duo ERREUR: {Message}", ex.Message);
    // L'application continue même en cas d'erreur de configuration Duo
    // pour permettre le diagnostic et la correction
}

/*
 * CONFIGURATION DU PIPELINE MIDDLEWARE
 * ------------------------------------
 * 
 * ORDRE D'EXÉCUTION (de haut en bas) :
 * 1. UseRouting : Détermine le routage des requêtes
 * 2. UseCors : Applique la politique CORS
 * 3. UseSession : Active la gestion des sessions
 * 4. Middleware personnalisé : Debug des sessions
 * 5. MapControllers : Mappe les contrôleurs API
 * 6. MapGet : Mappe les endpoints spécifiques
 */
app.UseRouting();           // Routage des requêtes vers les contrôleurs
app.UseCors("AllowAll");    // Application de la politique CORS
app.UseSession();           // Activation de la gestion des sessions

/*
 * MIDDLEWARE DE DEBUG DES SESSIONS
 * --------------------------------
 * 
 * Ce middleware personnalisé affiche des informations de débogage
 * sur les sessions pour faciliter le développement et le dépannage.
 * 
 * FONCTIONNALITÉS :
 * - Affiche l'ID de session
 * - Affiche les clés de session
 * - Gère les erreurs de session
 * - Logs de débogage uniquement
 */
app.Use(async (context, next) =>
{
    try
    {
        if (context.Session != null && context.Session.IsAvailable)
        {
            app.Logger.LogDebug("Session ID: {SessionId}, Keys: {Keys}",
                context.Session.Id, string.Join(", ", context.Session.Keys));
        }
        else
        {
            app.Logger.LogWarning("⚠️ La session n'est pas disponible pour cette requête.");
        }
    }
    catch (InvalidOperationException ex)
    {
        app.Logger.LogWarning("⚠️ Erreur session: {Message}", ex.Message);
    }
    await next();
});

/*
 * MAPPAGE DES ENDPOINTS
 * ---------------------
 * 
 * - MapControllers : Active tous les contrôleurs API
 * - MapGet("/health") : Endpoint de santé pour le monitoring
 */
app.MapControllers();
app.MapGet("/health", () => new { status = "healthy", timestamp = DateTime.UtcNow });

/*
 * ========================================================================
 * CONFIGURATION DES URLs D'ÉCOUTE
 * ========================================================================
 * 
 * Cette section configure les URLs sur lesquelles l'application écoute.
 * 
 * MODES DE DÉPLOIEMENT :
 * ----------------------
 * 1. DÉVELOPPEMENT : dotnet run (utilise ces URLs)
 * 2. PRODUCTION IIS : Les URLs sont gérées par IIS via web.config
 * 3. SERVICE WINDOWS : Utilise les URLs configurées ici
 * 
 * PORTS CONFIGURÉS :
 * ------------------
 * - HTTP : 8080 (pour développement et tests)
 * - HTTPS : 8081 (nécessite certificat SSL)
 * 
 * CONFIGURATIONS COMMENTÉES :
 * ---------------------------
 * Les URLs commentées ci-dessous sont des exemples de configuration
 * pour différents environnements de déploiement.
 * 
 * ========================================================================
 */

// Configuration pour l'accès externe (exemples commentés)
// app.Urls.Add("http://0.0.0.0:8080");  // Écoute sur toutes les interfaces
// app.Urls.Add("https://0.0.0.0:8080"); // HTTPS si disponible
// app.Urls.Add("http://0.0.0.0:2012");  // Écoute sur toutes les interfaces
// app.Urls.Add("https://test.cafecacao.ci:2012"); // HTTPS si disponible

// Configuration pour IIS - pas de configuration d'URLs spécifiques
// Configuration pour IIS - les URLs sont gérées par IIS via web.config

/*
 * CONFIGURATION ACTIVE DES URLs
 * -----------------------------
 * 
 * Ces URLs sont utilisées en mode développement et pour les tests.
 * En production avec IIS, ces URLs sont ignorées car IIS gère le routage.
 */
app.Urls.Add("http://0.0.0.0:8080");  // HTTP sur toutes les interfaces
app.Urls.Add("https://0.0.0.0:8081"); // HTTPS sur toutes les interfaces

/*
 * DÉMARRAGE DE L'APPLICATION
 * --------------------------
 * 
 * Cette ligne démarre l'application et commence à écouter les requêtes
 * sur les URLs configurées ci-dessus.
 * 
 * L'application reste en vie jusqu'à ce qu'elle soit arrêtée (Ctrl+C, IIS, etc.)
 */
app.Run();