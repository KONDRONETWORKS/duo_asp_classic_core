# Configuration SSL pour DuoSigec4

## Vue d'ensemble
Ce document explique comment configurer SSL/TLS pour l'application DuoSigec4 sur le domaine `test.cafecacao.ci:2012`.

## Prérequis

### 1. Certificat SSL
- Certificat SSL valide pour `test.cafecacao.ci`
- Format : .pfx ou .p12 (avec clé privée)
- Chaîne de certificats complète

### 2. Modules IIS requis
- URL Rewrite Module
- HTTP Redirect Module

## Étapes de Configuration

### 1. Installation du Certificat

#### Via le Gestionnaire des Services Internet (IIS)
1. Ouvrir le Gestionnaire des Services Internet
2. Sélectionner le serveur dans l'arborescence
3. Double-cliquer sur "Certificats de serveur"
4. Clic droit → "Importer..."
5. Sélectionner le fichier .pfx
6. Entrer le mot de passe du certificat
7. Sélectionner le magasin de certificats : "Personnel"

#### Via PowerShell (Alternative)
```powershell
# Importer le certificat
$certPath = "C:\path\to\your\certificate.pfx"
$certPassword = "your-certificate-password"
$cert = Import-PfxCertificate -FilePath $certPath -CertStoreLocation "Cert:\LocalMachine\My" -Password (ConvertTo-SecureString -String $certPassword -AsPlainText -Force)

# Vérifier l'importation
Get-ChildItem -Path "Cert:\LocalMachine\My" | Where-Object {$_.Subject -like "*test.cafecacao.ci*"}
```

### 2. Configuration du Binding HTTPS

#### Via le Gestionnaire des Services Internet
1. Sélectionner le site "DuoSigec4"
2. Clic droit → "Modifier les liaisons..."
3. Cliquer sur "Ajouter..."
4. Configuration :
   - **Type** : https
   - **Adresse IP** : Toutes les adresses IP non assignées
   - **Port** : 2012
   - **Nom d'hôte** : test.cafecacao.ci
   - **Certificat SSL** : Sélectionner votre certificat

#### Via PowerShell
```powershell
# Créer le binding HTTPS
New-WebBinding -Name "DuoSigec4" -Protocol "https" -Port 2012 -HostHeader "test.cafecacao.ci"

# Assigner le certificat
$cert = Get-ChildItem -Path "Cert:\LocalMachine\My" | Where-Object {$_.Subject -like "*test.cafecacao.ci*"} | Select-Object -First 1
$binding = Get-WebBinding -Name "DuoSigec4" -Protocol "https" -Port 2012
$binding.AddSslCertificate($cert.Thumbprint, "my")
```

### 3. Configuration de la Redirection HTTPS

Le fichier `web.config` contient déjà la règle de redirection :

```xml
<rewrite>
    <rules>
        <rule name="Redirect to HTTPS" stopProcessing="true">
            <match url=".*" />
            <conditions>
                <add input="{HTTPS}" pattern="off" ignoreCase="true" />
            </conditions>
            <action type="Redirect" url="https://{HTTP_HOST}:2012{REQUEST_URI}" redirectType="Permanent" />
        </rule>
    </rules>
</rewrite>
```

### 4. Configuration des En-têtes de Sécurité

Les en-têtes de sécurité sont configurés dans `web.config` :

```xml
<httpProtocol>
    <customHeaders>
        <add name="X-Content-Type-Options" value="nosniff" />
        <add name="X-Frame-Options" value="DENY" />
        <add name="X-XSS-Protection" value="1; mode=block" />
        <add name="Strict-Transport-Security" value="max-age=31536000; includeSubDomains" />
    </customHeaders>
</httpProtocol>
```

### 5. Test de la Configuration SSL

#### Vérification du Certificat
```powershell
# Tester la connexion SSL
$response = Invoke-WebRequest -Uri "https://test.cafecacao.ci:2012/health" -UseBasicParsing
Write-Host "Status Code: $($response.StatusCode)"
Write-Host "Headers: $($response.Headers)"
```

#### Vérification avec OpenSSL
```bash
# Tester la connexion SSL
openssl s_client -connect test.cafecacao.ci:2012 -servername test.cafecacao.ci

# Vérifier le certificat
openssl s_client -connect test.cafecacao.ci:2012 -servername test.cafecacao.ci -showcerts
```

#### Vérification en ligne
- Utiliser des outils comme SSL Labs (https://www.ssllabs.com/ssltest/)
- Entrer l'URL : `https://test.cafecacao.ci:2012`

## Dépannage SSL

### Problèmes Courants

#### 1. Erreur "Certificat non approuvé"
- Vérifier que le certificat est installé dans le bon magasin
- Vérifier que la chaîne de certificats est complète
- Vérifier que le certificat n'est pas expiré

#### 2. Erreur "Nom de certificat ne correspond pas"
- Vérifier que le certificat contient le nom de domaine `test.cafecacao.ci`
- Vérifier que le binding IIS utilise le bon nom d'hôte

#### 3. Erreur "Connexion refusée"
- Vérifier que le port 2012 est ouvert dans le pare-feu
- Vérifier que le service IIS est démarré
- Vérifier que l'application est en cours d'exécution

### Commandes de Diagnostic

```powershell
# Vérifier les certificats installés
Get-ChildItem -Path "Cert:\LocalMachine\My" | Where-Object {$_.Subject -like "*cafecacao*"}

# Vérifier les bindings IIS
Get-WebBinding -Name "DuoSigec4"

# Vérifier les ports en écoute
netstat -an | findstr :2012

# Tester la connectivité
Test-NetConnection -ComputerName test.cafecacao.ci -Port 2012
```

## Renouvellement du Certificat

### 1. Sauvegarde
Avant le renouvellement, sauvegarder :
- Le certificat actuel
- La configuration IIS
- Les fichiers de l'application

### 2. Installation du Nouveau Certificat
1. Importer le nouveau certificat
2. Mettre à jour le binding IIS
3. Redémarrer le site web
4. Tester la configuration

### 3. Suppression de l'Ancien Certificat
Une fois le nouveau certificat validé :
1. Supprimer l'ancien certificat du magasin
2. Vérifier que l'application fonctionne toujours

## Sécurité

### Recommandations
1. **Certificat Wildcard** : Utiliser un certificat wildcard pour `*.cafecacao.ci` si possible
2. **Renouvellement Automatique** : Configurer le renouvellement automatique
3. **Force HTTPS** : S'assurer que toutes les communications utilisent HTTPS
4. **HSTS** : L'en-tête Strict-Transport-Security est déjà configuré

### Monitoring
- Surveiller l'expiration du certificat
- Configurer des alertes pour les erreurs SSL
- Monitorer les logs d'accès pour détecter les tentatives d'accès HTTP

## Support

En cas de problème :
1. Vérifier les logs IIS
2. Vérifier les logs de l'application
3. Tester la connectivité réseau
4. Vérifier la configuration du certificat
5. Contacter l'équipe de sécurité ou l'administrateur système
