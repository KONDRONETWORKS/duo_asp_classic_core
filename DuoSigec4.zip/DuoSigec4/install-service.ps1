# install-service.ps1
# Installation simple du service Windows DuoSigec4

param(
    [string]$ServiceName = "DuoSigec4",
    [string]$PublishPath = "C:\inetpub\wwwroot\DuoSigec4"
)

Write-Host "=== Installation Service DuoSigec4 ===" -ForegroundColor Green

# Vérifier les privilèges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit être exécuté en tant qu'administrateur."
    exit 1
}

# 1. Compilation et publication
Write-Host "`n1. Compilation..." -ForegroundColor Yellow
dotnet publish DuoSigec4.csproj -c Release -o $PublishPath --self-contained false
if ($LASTEXITCODE -ne 0) {
    Write-Error "Échec de la compilation."
    exit 1
}
Write-Host "✅ Compilation OK" -ForegroundColor Green

# 2. Création des dossiers
Write-Host "`n2. Création des dossiers..." -ForegroundColor Yellow
if (-not (Test-Path $PublishPath)) {
    New-Item -Path $PublishPath -ItemType Directory -Force
}
if (-not (Test-Path "$PublishPath\logs")) {
    New-Item -Path "$PublishPath\logs" -ItemType Directory -Force
}
Write-Host "✅ Dossiers créés" -ForegroundColor Green

# 3. Suppression du service existant
Write-Host "`n3. Suppression du service existant..." -ForegroundColor Yellow
if (Get-Service -Name $ServiceName -ErrorAction SilentlyContinue) {
    Stop-Service -Name $ServiceName -ErrorAction SilentlyContinue
    sc.exe delete $ServiceName
    Start-Sleep -Seconds 3
}
Write-Host "✅ Service existant supprimé" -ForegroundColor Green

# 4. Création du service
Write-Host "`n4. Création du service..." -ForegroundColor Yellow
$exePath = Join-Path $PublishPath "DuoSigec4.exe"
sc.exe create $ServiceName binPath="`"$exePath`" --service" DisplayName="DuoSigec4 Authentication Service" start= auto
if ($LASTEXITCODE -ne 0) {
    Write-Error "Échec de la création du service."
    exit 1
}
Write-Host "✅ Service créé" -ForegroundColor Green

# 5. Configuration du pare-feu
Write-Host "`n5. Configuration du pare-feu..." -ForegroundColor Yellow
$ports = @(9000, 9001, 8080, 2012)
foreach ($port in $ports) {
    $ruleName = "$ServiceName Port $port"
    if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
        Remove-NetFirewallRule -DisplayName $ruleName
    }
    New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow
}
Write-Host "✅ Pare-feu configuré" -ForegroundColor Green

# 6. Démarrage du service
Write-Host "`n6. Démarrage du service..." -ForegroundColor Yellow
Start-Service -Name $ServiceName
Start-Sleep -Seconds 5
$serviceStatus = (Get-Service -Name $ServiceName).Status
if ($serviceStatus -eq "Running") {
    Write-Host "✅ Service démarré" -ForegroundColor Green
} else {
    Write-Warning "⚠️ Service non démarré (Statut: $serviceStatus)"
    Write-Host "L'application peut être lancée avec: dotnet run" -ForegroundColor Yellow
}

Write-Host "`n=== Installation terminée ===" -ForegroundColor Green
Write-Host "URLs d'accès:" -ForegroundColor Cyan
Write-Host "  http://172.16.32.40:9000/health" -ForegroundColor White
Write-Host "  http://172.16.32.40:9000/api/duoauth/duo-auth?username=test" -ForegroundColor White
