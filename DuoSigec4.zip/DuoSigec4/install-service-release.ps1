# install-service-release.ps1
# Installation du service Windows DuoSigec4 en mode Release

param(
    [string]$ServiceName = "DuoSigec4",
    [string]$PublishPath = "E:\web_files\DuoSigec4\publish"
)

Write-Host "=== Installation Service DuoSigec4 (Release) ===" -ForegroundColor Green

# Verifier les privileges administrateur
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Error "Ce script doit etre execute en tant qu'administrateur."
    exit 1
}

# 1. Configuration des ports
Write-Host "`n1. Configuration des autorisations sur les ports..." -ForegroundColor Yellow
netsh http add urlacl url=http://+:9000/ user=Everyone 2>$null
netsh http add urlacl url=https://+:9001/ user=Everyone 2>$null
netsh http add urlacl url=http://+:2012/ user=Everyone 2>$null
Write-Host "V Ports configures" -ForegroundColor Green

# 2. Suppression des anciens services
Write-Host "`n2. Suppression des anciens services..." -ForegroundColor Yellow
$oldServices = @("DuoSigec4", "DuoSigec4Service", "DuoSigec4New", "DuoSigec4163951", "DuoSigec4164805")
foreach ($oldService in $oldServices) {
    if (Get-Service -Name $oldService -ErrorAction SilentlyContinue) {
        Stop-Service -Name $oldService -Force -ErrorAction SilentlyContinue
        sc.exe delete $oldService 2>$null
        Start-Sleep -Seconds 1
    }
}
Write-Host "V Anciens services supprimes" -ForegroundColor Green

# Attendre que la suppression soit finalisee
Start-Sleep -Seconds 5

# 3. Creation du nouveau service
Write-Host "`n3. Creation du service..." -ForegroundColor Yellow
$exePath = Join-Path $PublishPath "DuoSigec4.exe"

if (-not (Test-Path $exePath)) {
    Write-Error "L'executable n'existe pas: $exePath"
    exit 1
}

# Generer un nom unique pour eviter les conflits
$timestamp = Get-Date -Format "yyyyMMddHHmmss"
$uniqueServiceName = "DuoSigec4_$timestamp"

$result = sc.exe create $uniqueServiceName binPath="`"$exePath`" --service" DisplayName="DuoSigec4 Service Release" start= auto

if ($LASTEXITCODE -eq 0) {
    Write-Host "V Service cree: $uniqueServiceName" -ForegroundColor Green
    
    # Configurer la description
    sc.exe description $uniqueServiceName "Service d'authentification Duo pour applications ASP Classic"
    
    # Configurer pour redemarrer automatiquement en cas d'echec
    sc.exe failure $uniqueServiceName reset= 86400 actions= restart/60000/restart/60000/restart/60000
    
    # 4. Demarrer le service
    Write-Host "`n4. Demarrage du service..." -ForegroundColor Yellow
    Start-Service -Name $uniqueServiceName -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 5
    
    $service = Get-Service -Name $uniqueServiceName -ErrorAction SilentlyContinue
    if ($service -and $service.Status -eq "Running") {
        Write-Host "V Service demarre" -ForegroundColor Green
        
        # Test de sante
        try {
            $response = Invoke-WebRequest -Uri "http://localhost:9000/health" -UseBasicParsing -TimeoutSec 5
            if ($response.StatusCode -eq 200) {
                Write-Host "V Health check OK" -ForegroundColor Green
            }
        } catch {
            Write-Host "! Health check echoue - Le service demarre peut-etre encore" -ForegroundColor Yellow
        }
    } else {
        Write-Host "X Service non demarre (Status: $($service.Status))" -ForegroundColor Red
        Write-Host "Verifiez les logs Windows Event Viewer" -ForegroundColor Yellow
    }
    
    Write-Host "`n=== Installation terminee ===" -ForegroundColor Green
    Write-Host "Nom du service: $uniqueServiceName" -ForegroundColor Cyan
    Write-Host "Chemin: $exePath" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "URLs d'acces:" -ForegroundColor Cyan
    Write-Host "  http://172.16.32.40:9000/health" -ForegroundColor White
    Write-Host "  http://172.16.32.40:9000/api/duoauth/duo-auth?username=USER&returnUrl=URL" -ForegroundColor White
    Write-Host ""
    Write-Host "Gestion du service:" -ForegroundColor Cyan
    Write-Host "  Voir: Get-Service -Name '$uniqueServiceName'" -ForegroundColor White
    Write-Host "  Arreter: Stop-Service -Name '$uniqueServiceName'" -ForegroundColor White
    Write-Host "  Demarrer: Start-Service -Name '$uniqueServiceName'" -ForegroundColor White
    Write-Host "  Supprimer: sc.exe delete '$uniqueServiceName'" -ForegroundColor White
    
} else {
    Write-Error "Echec de la creation du service. Code d'erreur: $LASTEXITCODE"
    Write-Host "Resultat: $result" -ForegroundColor Red
    exit 1
}

